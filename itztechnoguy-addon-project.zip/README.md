# ItzTechnoGuy's Addon 1.11.2 (Meteor Client, Minecraft 1.21.11)

All modules are in the **ItzTechnoGuy** tab of the Meteor GUI:
- X-Bow Cart (default key B), TNT Cart Refill
- Silent Totem
- Mending Scan
- Area Miner (holds left click like a hand: only blocks under the crosshair are mined; the camera sweeps over the zone)
- Shield Stun
- Bow Boost (bind your own key)
- Mining Recorder (records your own mining into itztechnoguy-recordings in the game folder)
- AFK Adjustments (one switch: one frame every few seconds, minimum distances, no sound, smaller memory use)

Upload this zip to the GitHub repo (`itztechnoguy-addon-project.zip`); the build runs automatically.
Put the resulting `itztechnoguy-addon-1.11.2.jar` in the `mods` folder next to Meteor (remove older versions).
