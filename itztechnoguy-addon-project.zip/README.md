# ItzTechnoGuy's Addon 1.1.0 (Meteor Client, Minecraft 1.21.11)

All modules are in the **ItzTechnoGuy** tab of the Meteor GUI:
- X-Bow Cart (default key B), TNT Cart Refill
- Silent Totem
- Mending Scan
- Area Miner
- Shield Stun
- Bow Boost (bind your own key)

Upload this zip to the GitHub repo (`itztechnoguy-addon-project.zip`); the build runs automatically.
Put the resulting `itztechnoguy-addon-1.1.0.jar` in the `mods` folder next to Meteor (remove older versions).
