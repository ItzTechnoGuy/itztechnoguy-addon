package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;

import java.util.Set;

/**
 * Trigger Bot by ItzTechnoGuy.
 *
 * Hits automatically, exactly like a click of yours would: only while a weapon is in your hand, only
 * when your crosshair is already on the hitbox of an allowed target (the game's own crosshair target,
 * so the normal reach applies), and only when the attack cooldown is full. It never turns the camera
 * and never changes the reach. Works together with Shield Stun: a raised shield that Shield Stun is
 * about to break is left to it.
 */
public class TriggerBot extends Module {
    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTargets = settings.createGroup("Targets");

    private final Setting<Boolean> swords = sgGeneral.add(new BoolSetting.Builder()
        .name("swords").description("Work while holding a sword.").defaultValue(true).build());

    private final Setting<Boolean> axes = sgGeneral.add(new BoolSetting.Builder()
        .name("axes").description("Work while holding an axe.").defaultValue(true).build());

    private final Setting<Boolean> mace = sgGeneral.add(new BoolSetting.Builder()
        .name("mace").description("Work while holding a mace.").defaultValue(false).build());

    private final Setting<Integer> minCooldown = sgGeneral.add(new IntSetting.Builder()
        .name("min-cooldown")
        .description("Hit only when the attack cooldown is at least this full, in %. 100 = a full-strength hit every time.")
        .defaultValue(100).range(0, 100).sliderRange(50, 100).build());

    private final Setting<Boolean> pauseWhenUsing = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-when-using-item")
        .description("Do not hit while you are eating, drinking or blocking with a shield.")
        .defaultValue(true).build());

    private final Setting<Set<EntityType<?>>> entities = sgTargets.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("What to hit when your crosshair is on it (players, hostile mobs, animals, ...).")
        .onlyAttackable()
        .defaultValue(EntityType.PLAYER)
        .build());

    private final Setting<Boolean> ignoreFriends = sgTargets.add(new BoolSetting.Builder()
        .name("ignore-friends").description("Never hit players on your friends list.").defaultValue(true).build());

    private final Setting<Boolean> ignoreBabies = sgTargets.add(new BoolSetting.Builder()
        .name("ignore-babies").description("Do not hit baby mobs.").defaultValue(true).build());

    public TriggerBot() {
        super(ItzTechnoGuyAddon.CATEGORY, "trigger-bot",
            "Hits whatever your crosshair is on, automatically, while you hold a weapon. By ItzTechnoGuy.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        if (client.screen != null) return;
        if (!holdingWeapon()) return;
        if (pauseWhenUsing.get() && client.player.isUsingItem()) return;

        // The same target a normal click would hit (the game checks reach and walls itself).
        if (!(client.hitResult instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (target == client.player || !target.isAlive()) return;
        if (!entities.get().contains(target.getType())) return;
        if (ignoreBabies.get() && target instanceof LivingEntity living && living.isBaby()) return;
        if (ignoreFriends.get() && target instanceof Player p && Friends.get().isFriend(p)) return;

        if (shieldStunHasIt(target)) return;

        if (client.player.getAttackStrengthScale(0.5F) < minCooldown.get() / 100.0F) return;

        client.gameMode.attack(client.player, target);
        client.player.swing(InteractionHand.MAIN_HAND);
    }

    private boolean holdingWeapon() {
        ItemStack held = client.player.getMainHandItem();
        if (swords.get() && held.is(ItemTags.SWORDS)) return true;
        if (axes.get() && held.is(ItemTags.AXES)) return true;
        return mace.get() && held.is(Items.MACE);
    }

    /** True when Shield Stun is on and is busy, just acted, or is about to break this target's shield. */
    private boolean shieldStunHasIt(Entity target) {
        ShieldStun stun = Modules.get().get(ShieldStun.class);
        if (stun == null || !stun.isActive()) return false;
        if (stun.isBusy()) return true;
        if (System.currentTimeMillis() - stun.lastStunTime < 150) return true;
        return stun.wouldStun(target);
    }
}
