package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * Bow Boost by ItzTechnoGuy: run, jump, draw the bow quickly straight UP, release, and the arrow
 * comes back down and pushes you forward. In 1.21.11 an arrow cannot hit its shooter until it has
 * left the shooter's body, so shooting down does nothing: the shot goes up. Bind a key to the
 * module; one press runs the whole sequence once and then the module switches itself off.
 * All times are in milliseconds (they are checked once per game tick, so they are rounded to 50 ms
 * at 20 TPS). Minecraft pitch: negative = up, positive = down.
 */
public class BowBoost extends Module {
    private enum Stage { IDLE, JUMP, DRAW, AFTER }

    /** Time of the last release, shared so the cooldown survives switching the module off and on. */
    private static long lastRelease = 0;

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> pitch = sg.add(new DoubleSetting.Builder()
        .name("pitch")
        .description("Look angle at the release. Minecraft pitch: -90 = straight up, 90 = straight down, so about -78 is almost up.")
        .defaultValue(-78.0).range(-90.0, 90.0).sliderRange(-90.0, 90.0).decimalPlaces(1).build());

    private final Setting<Integer> drawTime = sg.add(new IntSetting.Builder()
        .name("draw-time")
        .description("How long the bow is drawn before the release, in ms (150 ms = 3 ticks). Too short or a laggy server = no arrow, raise it.")
        .defaultValue(150).range(50, 1500).sliderRange(50, 600).build());

    private final Setting<Boolean> jump = sg.add(new BoolSetting.Builder()
        .name("jump")
        .description("Jump first, then draw the bow in the air.")
        .defaultValue(true).build());

    private final Setting<Integer> jumpDelay = sg.add(new IntSetting.Builder()
        .name("jump-delay")
        .description("Time between the jump and the start of the draw, in ms.")
        .defaultValue(120).range(0, 1000).sliderRange(0, 400).visible(jump::get).build());

    private final Setting<Boolean> sprint = sg.add(new BoolSetting.Builder()
        .name("sprint")
        .description("Hold forward and sprint during the sequence.")
        .defaultValue(true).build());

    private final Setting<Integer> cooldown = sg.add(new IntSetting.Builder()
        .name("cooldown")
        .description("Minimum time between two boosts, in ms.")
        .defaultValue(1000).range(0, 10000).sliderRange(0, 5000).build());

    private final Setting<Boolean> requireArrows = sg.add(new BoolSetting.Builder()
        .name("require-arrows")
        .description("Only work when there is a bow and arrows in the hotbar (not needed in creative).")
        .defaultValue(true).build());

    private final Setting<Boolean> restoreCamera = sg.add(new BoolSetting.Builder()
        .name("restore-camera")
        .description("Turn the camera back to the angle it had before the boost.")
        .defaultValue(true).build());

    private final Setting<Integer> restoreDelay = sg.add(new IntSetting.Builder()
        .name("restore-delay")
        .description("Time after the release before the camera turns back, in ms.")
        .defaultValue(100).range(0, 2000).sliderRange(0, 500).visible(restoreCamera::get).build());

    private final Setting<Integer> measureTime = sg.add(new IntSetting.Builder()
        .name("measure-time")
        .description("How long after the release the speed is measured (and the module stays on), in ms.")
        .defaultValue(700).range(100, 3000).sliderRange(100, 2000).build());

    private final Setting<Boolean> debug = sg.add(new BoolSetting.Builder()
        .name("debug")
        .description("Print your horizontal speed before and after the boost, and why it stopped if it did.")
        .defaultValue(true).build());

    private Stage stage = Stage.IDLE;
    private long t0, t1;
    private boolean swapped, keysSaved, camRestored;
    private boolean wasUp, wasSprint, wasJump;
    private float oldYaw, oldPitch;
    private double speedBefore, peakAfter, speedAtRelease;

    public BowBoost() {
        super(ItzTechnoGuyAddon.CATEGORY, "bow-boost", "Experimental: run, jump, draw the bow straight up, release, and the falling arrow pushes you forward. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        stage = Stage.IDLE;
        swapped = false;
        keysSaved = false;
        camRestored = false;

        if (client.player == null || client.gameMode == null || client.options == null) {
            toggle();
            return;
        }
        if (client.screen != null) {
            fail("a screen is open.");
            return;
        }
        long now = System.currentTimeMillis();
        long left = cooldown.get() - (now - lastRelease);
        if (left > 0) {
            fail("cooldown, " + left + " ms left.");
            return;
        }
        if (client.player.isUsingItem()) {
            fail("you are already using an item.");
            return;
        }

        int bow = findHotbar(Items.BOW);
        if (bow < 0) {
            error("No bow in the hotbar.");
            toggle();
            return;
        }
        if (requireArrows.get() && !client.player.isCreative() && !hotbarHasArrows()) {
            error("No arrows in the hotbar.");
            toggle();
            return;
        }

        wasUp = client.options.keyUp.isDown();
        wasSprint = client.options.keySprint.isDown();
        wasJump = client.options.keyJump.isDown();
        keysSaved = true;

        InvUtils.swap(bow, true);
        swapped = true;

        speedBefore = horizontalSpeed();
        peakAfter = 0;
        t0 = now;

        if (sprint.get()) {
            client.options.keyUp.setDown(true);
            client.options.keySprint.setDown(true);
        }
        if (jump.get() && client.player.onGround()) client.options.keyJump.setDown(true);
        stage = Stage.JUMP;
    }

    @Override
    public void onDeactivate() {
        if (client.options != null && keysSaved) {
            client.options.keyUp.setDown(wasUp);
            client.options.keySprint.setDown(wasSprint);
            client.options.keyJump.setDown(wasJump);
            // Letting go of "use" makes the game release the bow by itself if it was still drawn.
            client.options.keyUse.setDown(false);
        }
        if (client.player != null && restoreCamera.get() && !camRestored && stage == Stage.DRAW) {
            client.player.setYRot(oldYaw);
            client.player.setXRot(oldPitch);
        }
        if (swapped) InvUtils.swapBack();
        swapped = false;
        keysSaved = false;
        stage = Stage.IDLE;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (stage == Stage.IDLE) return;
        if (client.player == null || client.gameMode == null) {
            toggle();
            return;
        }
        if (client.screen != null) {
            fail("a screen was opened.");
            return;
        }
        long now = System.currentTimeMillis();

        switch (stage) {
            case JUMP -> {
                client.options.keyJump.setDown(false);   // one tick of jump is enough
                if (now - t0 < (jump.get() ? jumpDelay.get() : 0)) return;

                // Turn up first and tell the server, then start drawing (the use packet carries the angle too).
                oldYaw = client.player.getYRot();
                oldPitch = client.player.getXRot();
                float p = Mth.clamp(pitch.get().floatValue(), -90f, 90f);
                client.player.setXRot(p);
                sendRotation(oldYaw, p);
                client.options.keyUse.setDown(true);
                client.gameMode.useItem(client.player, InteractionHand.MAIN_HAND);
                t1 = now;
                stage = Stage.DRAW;
            }
            case DRAW -> {
                if (!client.player.isUsingItem()) {
                    fail("the bow did not start drawing (no arrows?).");
                    return;
                }
                if (now - t1 < drawTime.get()) return;

                float p = client.player.getXRot();
                sendRotation(client.player.getYRot(), p);
                client.gameMode.releaseUsingItem(client.player);
                client.options.keyUse.setDown(false);
                speedAtRelease = horizontalSpeed();
                lastRelease = now;
                t1 = now;
                stage = Stage.AFTER;
            }
            case AFTER -> {
                peakAfter = Math.max(peakAfter, horizontalSpeed());
                if (restoreCamera.get() && !camRestored && now - t1 >= restoreDelay.get()) {
                    client.player.setYRot(oldYaw);
                    client.player.setXRot(oldPitch);
                    camRestored = true;
                }
                if (now - t1 < measureTime.get()) return;
                if (debug.get()) {
                    info("Bow boost: speed before " + blocksPerSecond(speedBefore) + ", at release "
                        + blocksPerSecond(speedAtRelease) + ", highest after " + blocksPerSecond(peakAfter) + ".");
                }
                toggle();
            }
            default -> { }
        }
    }

    /** Stops the sequence and (with debug on) says why. */
    private void fail(String reason) {
        if (debug.get()) warning("Bow boost stopped: " + reason);
        toggle();
    }

    /** Tells the server the new look direction right away, instead of waiting for the next game tick. */
    private void sendRotation(float yaw, float pitchValue) {
        if (client.getConnection() == null || client.player == null) return;
        client.getConnection().send(new ServerboundMovePlayerPacket.Rot(yaw, pitchValue,
            client.player.onGround(), client.player.horizontalCollision));
    }

    private int findHotbar(net.minecraft.world.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (client.player.getInventory().getItem(i).is(item)) return i;
        }
        return -1;
    }

    private boolean hotbarHasArrows() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            if (s.is(Items.ARROW) || s.is(Items.TIPPED_ARROW) || s.is(Items.SPECTRAL_ARROW)) return true;
        }
        return false;
    }

    private double horizontalSpeed() {
        Vec3 dm = client.player.getDeltaMovement();
        return Math.hypot(dm.x, dm.z);
    }

    private String blocksPerSecond(double perTick) {
        return (Math.round(perTick * 200) / 10.0) + " blocks/s";
    }
}
