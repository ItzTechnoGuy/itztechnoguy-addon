package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundSelectTradePacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MerchantMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.phys.AABB;

/**
 * Snow Trader by ItzTechnoGuy: turns the diamonds and emeralds in your vaults into snowflakes.
 *
 * Mark the two NPCs once (look at the NPC and press its key, like the Area Miner corners). Then each
 * run: take the ores out of the ore vaults, /spawn, walk (Baritone) to the ore NPC and trade (trade 0,
 * then trade 1, as often as it goes), walk to the snowflake NPC and trade, store the snowflakes in
 * their own vault, repeat until the ore vaults are empty, then /team home.
 * The nearby-player check of Vault Miner is NOT active here (spawn is crowded).
 */
public class SnowTrader extends Module {
    private final Minecraft client = Minecraft.getInstance();

    private static final int RESERVE = 8;          // empty slots kept free for snowballs and snowflakes
    private static final long CLICK_MS = 150;
    private static final long WALK_TIMEOUT_MS = 45_000;
    private static final long OPEN_TIMEOUT_MS = 4_000;

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Keybind> oreKey = sg.add(new KeybindSetting.Builder()
        .name("ore-npc-key").description("Look at the ORE NPC (stand next to it) and press this key to remember it.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Keybind> flakeKey = sg.add(new KeybindSetting.Builder()
        .name("snowflake-npc-key").description("Look at the SNOWFLAKE NPC and press this key to remember it.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Integer> oreFirst = sg.add(new IntSetting.Builder()
        .name("ore-vault-first").description("First /pv number that holds diamonds and emeralds.")
        .defaultValue(1).range(1, 99).sliderRange(1, 10).build());

    private final Setting<Integer> oreLast = sg.add(new IntSetting.Builder()
        .name("ore-vault-last").description("Last /pv number that holds diamonds and emeralds.")
        .defaultValue(1).range(1, 99).sliderRange(1, 10).build());

    private final Setting<Integer> flakeVault = sg.add(new IntSetting.Builder()
        .name("snowflake-vault").description("The /pv number where the snowflakes go (it can be the same as an ore vault).")
        .defaultValue(2).range(1, 99).sliderRange(1, 10).build());

    private final Setting<Integer> spawnWait = sg.add(new IntSetting.Builder()
        .name("spawn-wait").description("Wait this long (ms) after /spawn.")
        .defaultValue(5000).range(1000, 15000).sliderRange(2000, 8000).build());

    private final Setting<Boolean> teamHome = sg.add(new BoolSetting.Builder()
        .name("team-home").description("Send /team home when everything is traded.")
        .defaultValue(true).build());

    // the remembered NPC spots (hidden, saved with the module)
    private final Setting<Boolean> oreSet = flag("ore-npc-set"), flakeSet = flag("snowflake-npc-set");
    private final Setting<Integer> oreX = coord("ore-npc-x"), oreY = coord("ore-npc-y"), oreZ = coord("ore-npc-z");
    private final Setting<Integer> flakeX = coord("flake-npc-x"), flakeY = coord("flake-npc-y"), flakeZ = coord("flake-npc-z");

    private Setting<Boolean> flag(String name) {
        return sg.add(new BoolSetting.Builder().name(name).description("Remembered.")
            .defaultValue(false).visible(() -> false).build());
    }

    private Setting<Integer> coord(String name) {
        return sg.add(new IntSetting.Builder().name(name).description("Remembered NPC spot.")
            .defaultValue(0).range(-30_000_000, 30_000_000).visible(() -> false).build());
    }

    private enum S { VAULT_OPEN, WITHDRAW, SPAWN, WALK, NPC_OPEN, TRADE, STORE, TEAM_HOME }

    private S state = S.VAULT_OPEN;
    private S afterOpen = S.WITHDRAW;
    private long nextAt, stateSince, selectAt;
    private int vaultNo, openTries, npcIdx, tradeIdx, tradeCount, lastSlot, sameSlot, cons, consSlot;
    private boolean atSpawn, needSelect, consolidateTried;
    private Item flakeItem;

    // set by Vault Miner when it runs this module as part of its loop
    public boolean chained, lastRunOk;
    private int chainFirst, chainLast;

    private int first() { return chained ? chainFirst : oreFirst.get(); }
    private int last() { return chained ? chainLast : oreLast.get(); }

    public boolean isReady() {
        return oreSet.get() && flakeSet.get();
    }

    /** Called by Vault Miner: use its vault range and always finish with /team home. */
    public void beginChained(int firstVault, int lastVault) {
        chained = true;
        chainFirst = firstVault;
        chainLast = lastVault;
    }

    public SnowTrader() {
        super(ItzTechnoGuyAddon.CATEGORY, "snow-trader",
            "Trades the ores in your vaults for snowflakes at the spawn NPCs. By ItzTechnoGuy.");
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onActivate() {
        if (client.player == null || client.level == null || client.getConnection() == null) {
            toggle();
            return;
        }
        if (!oreSet.get() || !flakeSet.get()) {
            error("I do not know both NPCs yet. Set ore-npc-key and snowflake-npc-key, look at each NPC and press its key.");
            toggle();
            return;
        }
        if (first() > last()) {
            error("ore-vault-first must not be higher than ore-vault-last.");
            toggle();
            return;
        }
        lastRunOk = false;
        atSpawn = false;
        flakeItem = null;
        npcIdx = 0;
        vaultNo = first();
        openVault(vaultNo, S.WITHDRAW, System.currentTimeMillis());
    }

    @Override
    public void onDeactivate() {
        chained = false;
        if (client.player != null && client.getConnection() != null) {
            chat("#stop");
            if (client.player.containerMenu != client.player.inventoryMenu) client.player.closeContainer();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (client.player == null || client.level == null || client.gameMode == null || client.getConnection() == null) {
            toggle();
            return;
        }
        long now = System.currentTimeMillis();
        switch (state) {
            case VAULT_OPEN -> tickVaultOpen(now);
            case WITHDRAW -> tickWithdraw(now);
            case SPAWN -> {
                if (now >= nextAt) startWalk(0, now);
            }
            case WALK -> tickWalk(now);
            case NPC_OPEN -> tickNpcOpen(now);
            case TRADE -> tickTrade(now);
            case STORE -> tickStore(now);
            case TEAM_HOME -> {
                if (now >= nextAt) toggle();
            }
        }
    }

    // ---------------------------------------------------------------- marking the NPCs (works with the module off)

    public void onGlobalKey(int key, int modifiers) {
        if (client.player == null || client.level == null || client.screen != null) return;
        boolean ore = oreKey.get().isSet() && oreKey.get().matches(true, key, modifiers);
        boolean flake = flakeKey.get().isSet() && flakeKey.get().matches(true, key, modifiers);
        if (!ore && !flake) return;
        Entity t = client.crosshairPickEntity;
        if (t == null) {
            warning("Look at the NPC first (stand right next to it).");
            return;
        }
        int x = Mth.floor(t.getX()), y = Mth.floor(t.getY()), z = Mth.floor(t.getZ());
        if (ore) {
            oreX.set(x);
            oreY.set(y);
            oreZ.set(z);
            oreSet.set(true);
            info("Ore NPC saved (" + x + " " + y + " " + z + ").");
        } else {
            flakeX.set(x);
            flakeY.set(y);
            flakeZ.set(z);
            flakeSet.set(true);
            info("Snowflake NPC saved (" + x + " " + y + " " + z + ").");
        }
    }

    // ---------------------------------------------------------------- vaults

    private void openVault(int number, S next, long now) {
        cmd("pv " + number);
        afterOpen = next;
        state = S.VAULT_OPEN;
        stateSince = now;
        openTries = 0;
        lastSlot = -1;
        sameSlot = 0;
        vaultNo = number;
    }

    private boolean vaultOpen(AbstractContainerMenu m) {
        return m != client.player.inventoryMenu && !(m instanceof MerchantMenu) && m.slots.size() > 36;
    }

    private void tickVaultOpen(long now) {
        if (vaultOpen(client.player.containerMenu)) {
            state = afterOpen;
            nextAt = now + CLICK_MS;
            return;
        }
        if (now - stateSince > OPEN_TIMEOUT_MS) {
            if (++openTries >= 3) {
                fail("The vault did not open. Stopping.");
                return;
            }
            cmd("pv " + vaultNo);
            stateSince = now;
        }
    }

    private void tickWithdraw(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (!vaultOpen(m)) {
            openVault(vaultNo, S.WITHDRAW, now);
            return;
        }
        if (now < nextAt) return;
        int vc = m.slots.size() - 36;
        if (freeSlots(m, vc) > RESERVE) {
            for (int i = 0; i < vc; i++) {
                if (!isOre(m.slots.get(i).getItem())) continue;
                if (i == lastSlot) {
                    if (++sameSlot > 4) break;   // the inventory cannot take more
                } else {
                    lastSlot = i;
                    sameSlot = 0;
                }
                click(i, 0, ClickType.QUICK_MOVE);
                spend(now);
                return;
            }
        }
        client.player.closeContainer();
        if (vaultNo < last()) {
            openVault(vaultNo + 1, S.WITHDRAW, now);
            return;
        }
        if (oreCount() < 32) {
            finish(now);
            return;
        }
        if (!atSpawn) {
            chat("#stop");
            cmd("spawn");
            atSpawn = true;
            state = S.SPAWN;
            nextAt = now + spawnWait.get();
        } else {
            startWalk(0, now);
        }
    }

    private void tickStore(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (!vaultOpen(m)) {
            openVault(flakeVault.get(), S.STORE, now);
            return;
        }
        if (now < nextAt) return;
        int vc = m.slots.size() - 36;
        if (flakeItem != null) {
            for (int i = vc; i < m.slots.size(); i++) {
                if (!m.slots.get(i).getItem().is(flakeItem)) continue;
                if (i == lastSlot) {
                    if (++sameSlot > 6) {
                        fail("The snowflake vault looks full. Stopping.");
                        return;
                    }
                } else {
                    lastSlot = i;
                    sameSlot = 0;
                }
                click(i, 0, ClickType.QUICK_MOVE);
                spend(now);
                return;
            }
        }
        client.player.closeContainer();
        openVault(first(), S.WITHDRAW, now);   // more ores to bring?
    }

    // ---------------------------------------------------------------- NPCs

    private int npcX() { return npcIdx == 0 ? oreX.get() : flakeX.get(); }
    private int npcY() { return npcIdx == 0 ? oreY.get() : flakeY.get(); }
    private int npcZ() { return npcIdx == 0 ? oreZ.get() : flakeZ.get(); }

    private void startWalk(int idx, long now) {
        npcIdx = idx;
        chat("#goto " + npcX() + " " + npcY() + " " + npcZ());
        state = S.WALK;
        stateSince = now;
    }

    private void tickWalk(long now) {
        double dx = client.player.getX() - (npcX() + 0.5), dz = client.player.getZ() - (npcZ() + 0.5);
        boolean near = dx * dx + dz * dz <= 6.25 && Math.abs(client.player.getY() - npcY()) < 3;
        if (near || now - stateSince > WALK_TIMEOUT_MS) {
            chat("#stop");
            state = S.NPC_OPEN;
            stateSince = now;
            openTries = 0;
            nextAt = now + 400;
        }
    }

    private void tickNpcOpen(long now) {
        if (client.player.containerMenu instanceof MerchantMenu) {
            tradeCount = 0;
            tradeIdx = 0;
            beginTrade(now);
            return;
        }
        if (now < nextAt) return;
        if (++openTries > 4) {
            fail("The NPC did not open a trade window. Stopping.");
            return;
        }
        Entity npc = findNpc();
        if (npc == null) {
            fail("No NPC found at the remembered spot. Mark the NPCs again.");
            return;
        }
        client.gameMode.interact(client.player, npc, InteractionHand.MAIN_HAND);
        nextAt = now + 1200;
    }

    private Entity findNpc() {
        double x = npcX() + 0.5, y = npcY(), z = npcZ() + 0.5;
        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : client.level.getEntities((Entity) null, new AABB(x - 3, y - 3, z - 3, x + 3, y + 4, z + 3),
            e -> e != client.player && !e.isSpectator() && e.isPickable())) {
            double d = e.distanceToSqr(x, y, z);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- trading

    private void beginTrade(long now) {
        needSelect = true;
        consolidateTried = false;
        cons = -1;
        selectAt = now;
        nextAt = now + CLICK_MS;
        state = S.TRADE;
    }

    private void tickTrade(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (!(m instanceof MerchantMenu mm)) {
            afterTrade(now);
            return;
        }
        if (now < nextAt) return;

        if (cons >= 0) {
            stepConsolidate(m, now);
            return;
        }

        ItemStack result = m.getSlot(2).getItem();
        if (!result.isEmpty()) {
            if (npcIdx == 1) flakeItem = result.getItem();
            click(2, 0, ClickType.QUICK_MOVE);   // take the result (shift-click)
            needSelect = true;                   // then the ingredients get filled in again
            if (++tradeCount >= 800) {
                nextTrade(now);
                return;
            }
            spend(now);
            return;
        }
        if (needSelect) {
            if (tradeIdx >= mm.getOffers().size()) {
                nextTrade(now);
                return;
            }
            client.getConnection().send(new ServerboundSelectTradePacket(tradeIdx));   // the server puts the ingredients in
            needSelect = false;
            selectAt = now;
            spend(now);
            return;
        }
        if (now - selectAt > 900) {
            // nothing came out: once, gather the ore into one stack by hand (pick up, double click, put in)
            if (!consolidateTried) {
                consolidateTried = true;
                Item need = requiredItem(mm);
                int s = need == null ? -1 : findInInventory(m, need);
                if (s >= 0) {
                    consSlot = s;
                    cons = 0;
                    return;
                }
            }
            nextTrade(now);   // nothing more to trade with this offer
        }
    }

    private void stepConsolidate(AbstractContainerMenu m, long now) {
        switch (cons) {
            case 0 -> {
                click(consSlot, 0, ClickType.PICKUP);        // lift one stack
                cons = 1;
            }
            case 1 -> {
                click(consSlot, 0, ClickType.PICKUP_ALL);    // double click: gather the rest of that item
                cons = 2;
            }
            case 2 -> {
                click(0, 0, ClickType.PICKUP);               // put it in the first ingredient slot
                cons = 3;
            }
            default -> {
                if (!m.getCarried().isEmpty()) {
                    int e = emptyInventorySlot(m);
                    if (e >= 0) click(e, 0, ClickType.PICKUP);
                }
                cons = -1;
                needSelect = false;
                selectAt = now;
            }
        }
        spend(now);
    }

    private Item requiredItem(MerchantMenu mm) {
        MerchantOffers offers = mm.getOffers();
        if (tradeIdx >= offers.size()) return null;
        ItemStack cost = offers.get(tradeIdx).getCostA();
        return cost.isEmpty() ? null : cost.getItem();
    }

    /** The ore NPC has one trade per ore (0, then 1); the snowflake NPC has one. */
    private void nextTrade(long now) {
        if (npcIdx == 0 && tradeIdx == 0) {
            tradeIdx = 1;
            beginTrade(now);
        } else {
            afterTrade(now);
        }
    }

    private void afterTrade(long now) {
        if (client.player.containerMenu != client.player.inventoryMenu) client.player.closeContainer();
        info("Trades done at this NPC: " + tradeCount);
        if (npcIdx == 0) {
            startWalk(1, now);
        } else {
            openVault(flakeVault.get(), S.STORE, now);
        }
    }

    // ---------------------------------------------------------------- end

    private void finish(long now) {
        if (client.player.containerMenu != client.player.inventoryMenu) client.player.closeContainer();
        chat("#stop");
        lastRunOk = true;
        if (teamHome.get() || chained) {
            cmd("team home");
            info("All traded. Sent /team home.");
            state = S.TEAM_HOME;
            nextAt = now + 2000;
        } else {
            info("All traded.");
            toggle();
        }
    }

    private void fail(String msg) {
        lastRunOk = false;
        error(msg);
        toggle();
    }

    // ---------------------------------------------------------------- helpers

    private boolean isOre(ItemStack s) {
        return s.is(Items.DIAMOND) || s.is(Items.EMERALD);
    }

    private int oreCount() {
        int n = 0;
        Inventory inv = client.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (isOre(s)) n += s.getCount();
        }
        return n;
    }

    private int freeSlots(AbstractContainerMenu m, int vc) {
        int n = 0;
        for (int i = vc; i < m.slots.size(); i++) if (m.slots.get(i).getItem().isEmpty()) n++;
        return n;
    }

    /** In the trade window the player's slots start after the 3 trade slots. */
    private int findInInventory(AbstractContainerMenu m, Item item) {
        for (int i = 3; i < m.slots.size(); i++) if (m.slots.get(i).getItem().is(item)) return i;
        return -1;
    }

    private int emptyInventorySlot(AbstractContainerMenu m) {
        for (int i = 3; i < m.slots.size(); i++) if (m.slots.get(i).getItem().isEmpty()) return i;
        return -1;
    }

    private void click(int slot, int button, ClickType type) {
        client.gameMode.handleInventoryMouseClick(client.player.containerMenu.containerId, slot, button, type, client.player);
    }

    private void spend(long now) {
        nextAt = now + CLICK_MS + (long) (Math.random() * CLICK_MS * 0.25);
    }

    private void chat(String msg) {
        if (client.getConnection() != null) client.getConnection().sendChat(msg);
    }

    private void cmd(String msg) {
        StringBuilder c = new StringBuilder();
        for (char ch : msg.toCharArray()) if (ch >= 32 && ch < 127) c.append(ch);
        String out = c.toString().trim();
        while (out.startsWith("/")) out = out.substring(1);
        if (!out.isEmpty() && client.getConnection() != null) client.getConnection().sendCommand(out);
    }
}
