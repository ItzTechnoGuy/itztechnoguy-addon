package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.AutoEat;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Vault Miner by ItzTechnoGuy: for a map with a bedrock floor and ore layers right above it.
 *
 * Baritone does the mining (diamond and emerald only, a few layers above the bedrock). Every empty
 * inventory slot is first filled with ONE diamond or ONE emerald (half and half), so nothing but
 * diamonds and emeralds can be picked up. When those stacks are nearly full the module opens
 * /pv 1 like a player would (real clicks, with a pause between them), stores the diamonds and
 * emeralds, fills the placeholders again and carries on. If a player comes too close it stops
 * Baritone and goes to /lobby at once, and leaves the server if that was not enough.
 * When Baritone finds nothing for a while it walks to the next chunk around the start point.
 */
public class VaultMiner extends Module {
    private final Minecraft client = Minecraft.getInstance();

    private static final long IDLE_MS = 10_000;
    private static final long EXPLORE_TIMEOUT_MS = 60_000;
    private static final long OPEN_TIMEOUT_MS = 4_000;
    private static final String MINE_CMD = "#mine diamond_ore deepslate_diamond_ore emerald_ore deepslate_emerald_ore";

    private final SettingGroup sg = settings.getDefaultGroup();

    public enum VaultType { PlayerVault, EnderChest }

    private final Setting<VaultType> vaultType = sg.add(new EnumSetting.Builder<VaultType>()
        .name("vault").description("Where the diamonds and emeralds go: a player vault (/pv) or the ender chest (/enderchest).")
        .defaultValue(VaultType.PlayerVault).build());

    private final Setting<Integer> vaultNumber = sg.add(new IntSetting.Builder()
        .name("vault-number").description("Which player vault (/pv number). Change it by hand when one is full.")
        .defaultValue(1).range(1, 99).sliderRange(1, 10)
        .visible(() -> vaultType.get() == VaultType.PlayerVault).build());

    private final Setting<Boolean> autoNextVault = sg.add(new BoolSetting.Builder()
        .name("auto-next-vault")
        .description("When the vault is full, move on: the next /pv number up to last-vault, then the ender chest if that is on.")
        .defaultValue(true).build());

    private final Setting<Integer> lastVault = sg.add(new IntSetting.Builder()
        .name("last-vault").description("The highest /pv number to use before giving up or going to the ender chest.")
        .defaultValue(3).range(1, 99).sliderRange(1, 10).visible(autoNextVault::get).build());

    private final Setting<Boolean> thenEnderChest = sg.add(new BoolSetting.Builder()
        .name("then-ender-chest").description("After the last /pv is full, use /enderchest.")
        .defaultValue(false).visible(autoNextVault::get).build());

    private final Setting<Boolean> tradeWhenFull = sg.add(new BoolSetting.Builder()
        .name("trade-when-full")
        .description("When every vault is full: run Snow Trader (trade the ores for snowflakes at spawn), come back with /team home, dig down to the bedrock and carry on.")
        .defaultValue(true).build());

    private final Setting<Boolean> autoEat = sg.add(new BoolSetting.Builder()
        .name("auto-eat")
        .description("Turn on Meteor's Auto Eat while this runs (it pauses Baritone while eating). Keep food in your inventory.")
        .defaultValue(true).build());

    private final Setting<Integer> fillPercent = sg.add(new IntSetting.Builder()
        .name("fill-percent").description("Go to the vault when the diamond or emerald stacks are this full, in %.")
        .defaultValue(70).range(20, 100).sliderRange(40, 95).build());

    private final Setting<List<Item>> dropItems = sg.add(new ItemListSetting.Builder()
        .name("drop-items").description("Junk that gets dropped before the placeholders are refilled. Nothing else is ever dropped.")
        .defaultValue(
            Items.COBBLESTONE, Items.COBBLED_DEEPSLATE, Items.STONE, Items.DEEPSLATE, Items.DIRT, Items.GRAVEL,
            Items.ANDESITE, Items.DIORITE, Items.GRANITE, Items.TUFF,
            Items.COAL, Items.COAL_ORE, Items.DEEPSLATE_COAL_ORE,
            Items.IRON_ORE, Items.DEEPSLATE_IRON_ORE, Items.RAW_IRON,
            Items.GOLD_ORE, Items.DEEPSLATE_GOLD_ORE, Items.RAW_GOLD,
            Items.COPPER_ORE, Items.DEEPSLATE_COPPER_ORE, Items.RAW_COPPER,
            Items.LAPIS_LAZULI, Items.LAPIS_ORE, Items.DEEPSLATE_LAPIS_ORE,
            Items.REDSTONE, Items.REDSTONE_ORE, Items.DEEPSLATE_REDSTONE_ORE)
        .build());

    private final Setting<Integer> junkTrigger = sg.add(new IntSetting.Builder()
        .name("junk-trigger").description("Go to the vault early when this many slots hold junk. 0 = off.")
        .defaultValue(4).range(0, 36).sliderRange(0, 12).build());

    private final Setting<Integer> settleTime = sg.add(new IntSetting.Builder()
        .name("settle-time").description("Wait this long (ms) after storing, before dropping junk and refilling, so late items do not mix in.")
        .defaultValue(1500).range(0, 5000).sliderRange(500, 3000).build());

    private final Setting<Integer> layers = sg.add(new IntSetting.Builder()
        .name("layers").description("How many layers above the bedrock floor to mine.")
        .defaultValue(5).range(1, 40).sliderRange(1, 15).build());

    private final Setting<Integer> chunkRadius = sg.add(new IntSetting.Builder()
        .name("chunk-radius").description("When no ore is left around you, walk to the neighbouring chunks up to this many chunks away from the start.")
        .defaultValue(3).range(0, 10).sliderRange(0, 6).build());

    private final Setting<Double> dangerDistance = sg.add(new DoubleSetting.Builder()
        .name("danger-distance").description("A player (not a friend) closer than this many blocks: stop, /lobby at once, leave the server if that is not enough.")
        .defaultValue(5.0).range(2.0, 20.0).sliderRange(3.0, 10.0).decimalPlaces(1).build());

    private final Setting<Integer> leaveDelay = sg.add(new IntSetting.Builder()
        .name("leave-delay").description("If you are still here this many ms after /lobby and a player is still close, leave the server.")
        .defaultValue(1000).range(0, 5000).sliderRange(200, 3000).build());

    private final Setting<Integer> clickDelay = sg.add(new IntSetting.Builder()
        .name("click-delay").description("Pause between inventory clicks, in ms (a little random on top), like a player.")
        .defaultValue(120).range(30, 1000).sliderRange(60, 400).build());

    private final Setting<Boolean> yFromBottom = sg.add(new BoolSetting.Builder()
        .name("baritone-y-from-world-bottom")
        .description("Baritone's Y limits count from the bottom of the world (its docs say so for worlds with negative Y). Turn off if it mines at the wrong height.")
        .defaultValue(true).build());

    private enum State { MINING, OPENING, DEPOSIT, SETTLE, DROP, REFILL, EXPLORE_GO, EXPLORE_WAIT, TRADING, RETURN_WAIT, DIG_DOWN, MANUAL_SIDE, MANUAL_DIG, LEAVING }

    private State state = State.MINING;
    private ClientLevel levelRef;
    private int lowY, highY, startCx, startCz;
    private long nextAt, stateSince, lastSample, lastProgress, miningSince;
    private Vec3 lastPos;
    private int lastOreCount;
    private int openTries, lastDepositSlot, depositFails, needD, needE;
    private boolean warnedStock, enabledAutoEat, noDiamond, noEmerald;
    private VaultType curType = VaultType.PlayerVault;
    private int curNumber = 1;
    private final List<int[]> targets = new ArrayList<>();
    private int exploreIdx, exploreX, exploreZ;
    private double digLastY;
    private long digProgressAt;
    private Vec3 sidePos;
    private boolean keysHeld;

    public VaultMiner() {
        super(ItzTechnoGuyAddon.CATEGORY, "vault-miner",
            "Baritone mines diamonds and emeralds near the bedrock floor and stores them in /pv 1. By ItzTechnoGuy.");
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onActivate() {
        if (client.player == null || client.level == null || client.getConnection() == null) {
            toggle();
            return;
        }
        levelRef = client.level;
        int minY = client.level.getMinY();
        BlockPos feet = client.player.blockPosition();
        int floor = Integer.MIN_VALUE;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(feet.getX(), feet.getY(), feet.getZ());
        for (int y = feet.getY(); y >= minY; y--) {
            p.setY(y);
            if (client.level.getBlockState(p).is(Blocks.BEDROCK)) {
                floor = y;
                break;
            }
        }
        if (floor == Integer.MIN_VALUE) {
            error("No bedrock floor found below you. Stand inside the ore layers of the map.");
            toggle();
            return;
        }
        lowY = floor + 1;
        highY = floor + layers.get();
        int minLimit = yFromBottom.get() ? lowY - minY : lowY;
        int maxLimit = yFromBottom.get() ? highY - minY : highY;
        chat("#set minYLevelWhileMining " + minLimit);
        chat("#set maxYLevelWhileMining " + maxLimit);
        info("Mining from Y " + lowY + " to Y " + highY + " (bedrock floor at Y " + floor + ").");

        buildTargets(feet.getX() >> 4, feet.getZ() >> 4);
        warnedStock = false;

        curType = vaultType.get();
        curNumber = vaultNumber.get();
        if (autoEat.get()) {
            AutoEat ae = Modules.get().get(AutoEat.class);
            if (ae != null && !ae.isActive()) {
                ae.toggle();
                enabledAutoEat = true;
            }
        }

        beginVault(System.currentTimeMillis());   // fill the placeholders before anything is mined
    }

    @Override
    public void onDeactivate() {
        releaseKeys();
        if (enabledAutoEat) {
            AutoEat ae = Modules.get().get(AutoEat.class);
            if (ae != null && ae.isActive()) ae.toggle();
            enabledAutoEat = false;
        }
        if (client.getConnection() != null && client.player != null && state != State.LEAVING) {
            chat("#stop");
            chat("#set minYLevelWhileMining reset");
            chat("#set maxYLevelWhileMining reset");
            if (client.player.containerMenu != client.player.inventoryMenu) client.player.closeContainer();
        }
    }

    // ---------------------------------------------------------------- main loop

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (client.player == null || client.level == null || client.gameMode == null || client.getConnection() == null) {
            toggle();
            return;
        }
        long now = System.currentTimeMillis();

        if (state != State.LEAVING && state != State.TRADING && state != State.RETURN_WAIT && dangerNear()) {
            leave(now);
            return;
        }

        switch (state) {
            case MINING -> tickMining(now);
            case OPENING -> tickOpening(now);
            case DEPOSIT -> tickDeposit(now);
            case SETTLE -> tickSettle(now);
            case DROP -> tickDrop(now);
            case REFILL -> tickRefill(now);
            case EXPLORE_GO -> {
                double dx = client.player.getX() - exploreX, dz = client.player.getZ() - exploreZ;
                if (dx * dx + dz * dz < 9 || now - stateSince > EXPLORE_TIMEOUT_MS) {
                    chat("#stop");
                    state = State.EXPLORE_WAIT;
                    stateSince = now;
                }
            }
            case EXPLORE_WAIT -> {
                if (now - stateSince > 3000) startMining(now);   // give the chunks time to load
            }
            case TRADING -> tickTrading(now);
            case RETURN_WAIT -> {
                if (now - stateSince > 4000) startDigDown(now);
            }
            case DIG_DOWN -> {
                double y = client.player.getY();
                if (y <= lowY + 3) {
                    finishDig(now);
                } else {
                    if (y < digLastY - 0.5) {
                        digLastY = y;
                        digProgressAt = now;
                    }
                    if (now - digProgressAt > 10_000) startManualDig(now);   // #goto does not get anywhere
                }
            }
            case MANUAL_SIDE -> {
                if (client.player.position().distanceToSqr(sidePos) >= 1.0 || now - stateSince > 1500) {
                    client.options.keyUp.setDown(false);
                    state = State.MANUAL_DIG;
                    stateSince = now;
                    digProgressAt = now;
                    digLastY = client.player.getY();
                }
            }
            case MANUAL_DIG -> tickManualDig(now);
            case LEAVING -> tickLeaving(now);
        }
    }

    private void buildTargets(int cx, int cz) {
        startCx = cx;
        startCz = cz;
        targets.clear();
        int r = chunkRadius.get();
        for (int ring = 1; ring <= r; ring++)
            for (int dx = -ring; dx <= ring; dx++)
                for (int dz = -ring; dz <= ring; dz++)
                    if (Math.max(Math.abs(dx), Math.abs(dz)) == ring) targets.add(new int[]{dx, dz});
        exploreIdx = 0;
    }

    // ---------------------------------------------------------------- trading the ores (Snow Trader)

    private boolean startTrade(long now) {
        SnowTrader st = Modules.get().get(SnowTrader.class);
        if (st == null || !st.isReady()) {
            warning("Snow Trader does not know the NPCs yet (set its two keys and mark them).");
            return false;
        }
        chat("#stop");
        if (client.player.containerMenu != client.player.inventoryMenu) client.player.closeContainer();
        st.beginChained(vaultNumber.get(), lastVault.get());
        info("Every vault is full: trading the ores for snowflakes.");
        state = State.TRADING;
        stateSince = now;
        if (!st.isActive()) st.toggle();
        return true;
    }

    private void tickTrading(long now) {
        SnowTrader st = Modules.get().get(SnowTrader.class);
        if (st != null && st.isActive()) return;
        if (st == null || !st.lastRunOk) {
            error("Trading did not finish. Stopping.");
            toggle();
            return;
        }
        state = State.RETURN_WAIT;   // /team home was sent: give the teleport time
        stateSince = now;
    }

    private void startDigDown(long now) {
        curType = vaultType.get();
        curNumber = vaultNumber.get();       // the ore vaults are empty again
        int x = Mth.floor(client.player.getX()), z = Mth.floor(client.player.getZ());
        buildTargets(x >> 4, z >> 4);
        int y = Mth.clamp(lowY + 1, lowY, highY);
        chat("#goto " + x + " " + y + " " + z);
        info("Back home: digging down to the ore layers.");
        state = State.DIG_DOWN;
        stateSince = now;
        digLastY = client.player.getY();
        digProgressAt = now;
    }

    private void finishDig(long now) {
        releaseKeys();
        chat("#stop");
        beginVault(now);   // placeholders first, then mining
    }

    /** #goto failed: step one block aside, look straight down and hold the left button until nothing breaks any more (bedrock). */
    private void startManualDig(long now) {
        chat("#stop");
        info("Baritone is not getting down. Digging down by hand.");
        for (int i = 0; i < 9; i++) {
            if (client.player.getInventory().getItem(i).is(ItemTags.PICKAXES)) {
                InvUtils.swap(i, false);
                break;
            }
        }
        sidePos = client.player.position();
        client.options.keyUp.setDown(true);
        keysHeld = true;
        state = State.MANUAL_SIDE;
        stateSince = now;
    }

    private void tickManualDig(long now) {
        client.player.setXRot(90.0F);
        client.options.keyAttack.setDown(true);
        keysHeld = true;
        double y = client.player.getY();
        if (Math.abs(y - digLastY) > 0.1) {
            digLastY = y;
            digProgressAt = now;
        }
        if (y <= lowY + 1.1 || now - digProgressAt > 3500) {   // bedrock: nothing breaks, nothing moves
            info("Reached the bottom. Starting to mine.");
            finishDig(now);
        } else if (now - stateSince > 600_000) {
            releaseKeys();
            error("Digging down takes too long. Stopping.");
            toggle();
        }
    }

    private void releaseKeys() {
        if (!keysHeld) return;
        client.options.keyAttack.setDown(false);
        client.options.keyUp.setDown(false);
        keysHeld = false;
    }

    // ---------------------------------------------------------------- mining and exploring

    private void startMining(long now) {
        chat(MINE_CMD);
        state = State.MINING;
        miningSince = now;
        lastProgress = now;
        lastSample = now;
        lastPos = client.player.position();
        lastOreCount = oreCount();
    }

    private void tickMining(long now) {
        if (now - lastSample >= 1000) {
            lastSample = now;
            int ores = oreCount();
            Vec3 pos = client.player.position();
            if (ores != lastOreCount || lastPos == null || pos.distanceToSqr(lastPos) >= 2.25) lastProgress = now;
            lastOreCount = ores;
            lastPos = pos;
        }
        if (needVisit()) {
            beginVault(now);
            return;
        }
        if (now - lastProgress > IDLE_MS && now - miningSince > 5000) startExplore(now);
    }

    private void startExplore(long now) {
        if (exploreIdx >= targets.size()) {
            info("No ore left within " + chunkRadius.get() + " chunks of the start. Done.");
            chat("#stop");
            toggle();
            return;
        }
        int[] t = targets.get(exploreIdx++);
        exploreX = (startCx + t[0]) * 16 + 8;
        exploreZ = (startCz + t[1]) * 16 + 8;
        int y = Mth.clamp(client.player.blockPosition().getY(), lowY, highY);
        chat("#goto " + exploreX + " " + y + " " + exploreZ);
        info("Nothing left here, walking to the next chunk (" + exploreIdx + " of " + targets.size() + ").");
        state = State.EXPLORE_GO;
        stateSince = now;
    }

    // ---------------------------------------------------------------- vault visit

    private void beginVault(long now) {
        chat("#stop");
        cmd(vaultCmd());
        state = State.OPENING;
        stateSince = now;
        openTries = 0;
        nextAt = now + 300;
    }

    private boolean vaultOpen(AbstractContainerMenu m) {
        return m != client.player.inventoryMenu && m.slots.size() > 36;
    }

    private void tickOpening(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (vaultOpen(m)) {
            state = State.DEPOSIT;
            lastDepositSlot = -1;
            depositFails = 0;
            nextAt = now + clickDelay.get();
            return;
        }
        if (now - stateSince > OPEN_TIMEOUT_MS) {
            if (++openTries >= 3) {
                error("The vault did not open (" + vaultCmd() + "). Stopping.");
                toggle();
                return;
            }
            cmd(vaultCmd());
            stateSince = now;
        }
    }

    private void tickDeposit(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (!vaultOpen(m)) {
            state = State.OPENING;
            stateSince = now;
            return;
        }
        if (now < nextAt) return;
        int vc = m.slots.size() - 36;
        for (int i = vc; i < m.slots.size(); i++) {
            if (!isOre(m.slots.get(i).getItem())) continue;
            if (i == lastDepositSlot) {
                if (++depositFails > 6) {
                    vaultFull(now);
                    return;
                }
            } else {
                lastDepositSlot = i;
                depositFails = 0;
            }
            click(i, 0, ClickType.QUICK_MOVE);
            spend(now);
            return;
        }
        // everything is stored: wait a moment, then drop the junk
        state = State.SETTLE;
        nextAt = now + settleTime.get();
    }

    private void tickSettle(long now) {
        if (!vaultOpen(client.player.containerMenu)) {
            state = State.OPENING;
            stateSince = now;
            return;
        }
        if (now >= nextAt) state = State.DROP;
    }

    private void tickDrop(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (!vaultOpen(m)) {
            state = State.OPENING;
            stateSince = now;
            return;
        }
        if (now < nextAt) return;
        int vc = m.slots.size() - 36;
        for (int i = vc; i < m.slots.size(); i++) {
            if (!isJunk(m.slots.get(i).getItem())) continue;
            click(i, 1, ClickType.THROW);   // button 1 = the whole stack
            spend(now);
            return;
        }
        planRefill(m, vc);   // junk is gone: count the empty slots now
        state = State.REFILL;
    }

    /** Half diamonds, half emeralds (an odd one goes to diamonds), counted on the real empty slots. */
    private void planRefill(AbstractContainerMenu m, int vc) {
        int empty = 0;
        for (int i = vc; i < m.slots.size(); i++) if (m.slots.get(i).getItem().isEmpty()) empty++;
        needD = (empty + 1) / 2;
        needE = empty / 2;
        noDiamond = false;
        noEmerald = false;
    }

    private void tickRefill(long now) {
        AbstractContainerMenu m = client.player.containerMenu;
        if (!vaultOpen(m)) {
            state = State.OPENING;
            stateSince = now;
            return;
        }
        if (now < nextAt) return;
        int vc = m.slots.size() - 36;
        ItemStack cur = m.getCarried();
        int empty = emptyPlayerSlot(m, vc);

        if (cur.isEmpty()) {
            Item kind = (needD > 0 && !noDiamond) ? Items.DIAMOND : ((needE > 0 && !noEmerald) ? Items.EMERALD : null);
            if (kind == null || empty < 0) {
                finishVault(now, empty >= 0);
                return;
            }
            int src = findInVault(m, vc, kind);
            if (src < 0) {
                // none of this kind left in the vault: its share goes to the other kind
                if (kind == Items.DIAMOND) {
                    noDiamond = true;
                    needE += needD;
                    needD = 0;
                } else {
                    noEmerald = true;
                    needD += needE;
                    needE = 0;
                }
                return;
            }
            click(src, 0, ClickType.PICKUP);
            spend(now);
            return;
        }

        Item kind = cur.getItem();
        int need = kind == Items.DIAMOND ? needD : (kind == Items.EMERALD ? needE : 0);
        if (need > 0 && empty >= 0) {
            click(empty, 1, ClickType.PICKUP);   // right click: puts exactly one
            if (kind == Items.DIAMOND) needD--; else needE--;
            spend(now);
            return;
        }
        // put the rest of the stack back into the vault
        int dst = vaultSlotFor(m, vc, cur);
        if (dst < 0 && empty >= 0) dst = empty;
        if (dst < 0) {
            error("No room to put the rest back. Stopping.");
            toggle();
            return;
        }
        click(dst, 0, ClickType.PICKUP);
        spend(now);
    }

    private void finishVault(long now, boolean stillEmpty) {
        client.player.closeContainer();
        if (stillEmpty && !warnedStock) {
            warnedStock = true;
            warning("Not enough diamonds or emeralds in the vault to fill every slot: other items can fill your inventory. Put a few stacks in the vault.");
        }
        startMining(now);
    }

    private void vaultFull(long now) {
        client.player.closeContainer();
        if (autoNextVault.get()) {
            if (curType == VaultType.PlayerVault && curNumber < lastVault.get()) {
                curNumber++;
                info("That vault is full, moving on to " + vaultCmd() + ".");
                beginVault(now);
                return;
            }
            if (curType == VaultType.PlayerVault && thenEnderChest.get()) {
                curType = VaultType.EnderChest;
                info("That vault is full, moving on to the ender chest.");
                beginVault(now);
                return;
            }
        }
        if (tradeWhenFull.get() && startTrade(System.currentTimeMillis())) return;
        error("The vault is full and there is no other vault to use. Stopping.");
        toggle();
    }

    // ---------------------------------------------------------------- danger

    private boolean dangerNear() {
        double d = dangerDistance.get();
        for (Player p : client.level.players()) {
            if (p == client.player || p.isSpectator()) continue;
            if (Friends.get().isFriend(p)) continue;
            if (client.player.distanceTo(p) <= d) return true;
        }
        return false;
    }

    private void leave(long now) {
        releaseKeys();
        chat("#stop");
        cmd("lobby");
        warning("A player is too close: /lobby sent.");
        state = State.LEAVING;
        stateSince = now;
    }

    private void tickLeaving(long now) {
        if (client.level != levelRef) {      // the server moved us
            toggle();
            return;
        }
        if (now - stateSince < leaveDelay.get()) return;
        if (dangerNear() && client.getConnection() != null) {
            client.getConnection().getConnection().disconnect(Component.literal("Vault Miner: a player came too close"));
        }
        toggle();
    }

    // ---------------------------------------------------------------- helpers

    private boolean isOre(ItemStack s) {
        return s.is(Items.DIAMOND) || s.is(Items.EMERALD);
    }

    private int oreCount() {
        int n = 0;
        Inventory inv = client.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (isOre(s)) n += s.getCount();
        }
        return n;
    }

    private boolean isJunk(ItemStack s) {
        return !s.isEmpty() && !isOre(s) && dropItems.get().contains(s.getItem());
    }

    /** Time for the vault: the diamond or emerald stacks are nearly full, or too many slots hold junk. */
    private boolean needVisit() {
        Inventory inv = client.player.getInventory();
        long usedD = 0, capD = 0, usedE = 0, capE = 0;
        int empty = 0, junk = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) {
                empty++;
            } else if (s.is(Items.DIAMOND)) {
                usedD += s.getCount();
                capD += s.getMaxStackSize();
            } else if (s.is(Items.EMERALD)) {
                usedE += s.getCount();
                capE += s.getMaxStackSize();
            } else if (isJunk(s)) {
                junk++;
            }
        }
        if (junkTrigger.get() > 0 && junk >= junkTrigger.get()) return true;
        double pct = fillPercent.get() / 100.0;
        if (capD > 0 && usedD >= capD * pct) return true;
        if (capE > 0 && usedE >= capE * pct) return true;
        return capD == 0 && capE == 0 && empty == 0;   // no placeholders and no room at all
    }

    private int emptyPlayerSlot(AbstractContainerMenu m, int vc) {
        for (int i = vc; i < m.slots.size(); i++) if (m.slots.get(i).getItem().isEmpty()) return i;
        return -1;
    }

    private int findInVault(AbstractContainerMenu m, int vc, Item kind) {
        for (int i = 0; i < vc; i++) if (m.slots.get(i).getItem().is(kind)) return i;
        return -1;
    }

    private int vaultSlotFor(AbstractContainerMenu m, int vc, ItemStack cur) {
        for (int i = 0; i < vc; i++) {
            ItemStack s = m.slots.get(i).getItem();
            if (!s.isEmpty() && s.is(cur.getItem()) && s.getCount() < s.getMaxStackSize()) return i;
        }
        for (int i = 0; i < vc; i++) if (m.slots.get(i).getItem().isEmpty()) return i;
        return -1;
    }

    private void click(int slot, int button, ClickType type) {
        client.gameMode.handleInventoryMouseClick(client.player.containerMenu.containerId, slot, button, type, client.player);
    }

    private void spend(long now) {
        long d = clickDelay.get();
        nextAt = now + d + (long) (Math.random() * d * 0.25);
    }

    private void chat(String msg) {
        if (client.getConnection() != null) client.getConnection().sendChat(msg);
    }

    /** The vault command, built from the settings so no typing is needed (plain ASCII only). */
    private String vaultCmd() {
        return curType == VaultType.EnderChest ? "enderchest" : "pv " + curNumber;
    }

    private void cmd(String msg) {
        StringBuilder c = new StringBuilder();
        for (char ch : msg.toCharArray()) if (ch >= 32 && ch < 127) c.append(ch);   // never send odd characters
        String out = c.toString().trim();
        while (out.startsWith("/")) out = out.substring(1);
        if (!out.isEmpty() && client.getConnection() != null) client.getConnection().sendCommand(out);
    }
}
