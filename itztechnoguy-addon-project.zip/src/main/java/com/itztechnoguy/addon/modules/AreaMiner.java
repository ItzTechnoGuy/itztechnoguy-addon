package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Area Miner by ItzTechnoGuy.
 *
 * You mark two corners (look at a block and press the corner key), then switch the module on. It
 * mines every block inside the box and nothing outside it. When the box is empty it waits until the
 * blocks have respawned (for example a mine that resets) and mines it again.
 *
 * Normal mode: every block is mined until it breaks. Instant mode: blocks that your current tool
 * breaks in one tick are broken a few per tick, anything slower is mined the normal way.
 * It uses the game's own break calls, like a player holding the attack button, and it only touches
 * blocks you can reach from where you stand.
 */
public class AreaMiner extends Module {
    public enum Mode { Normal, Instant }

    public enum Order { Auto, Nearest, BottomUp, TopDown, TwoLayersThenUp }

    public enum CameraStyle { Direct, Calm }

    public enum ZoneMode { Auto, Preset }

    private enum Stage { MINING, WAIT_RESPAWN, WALKING }

    private static final int MAX_VOLUME = 100_000;

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();
    private final SettingGroup sgArea = settings.createGroup("Area");
    private final SettingGroup sgRepeat = settings.createGroup("Repeat");
    private final SettingGroup sgMove = settings.createGroup("Movement");
    private final SettingGroup sgItems = settings.createGroup("Items");
    private final SettingGroup sgSafety = settings.createGroup("Safety");

    // ---- Mining

    private final Setting<Integer> speed = sg.add(new IntSetting.Builder()
        .name("speed")
        .description("How fast the camera sweeps from block to block, in % of your own recording (100 = about 260 degrees per second). Lower = calmer.")
        .defaultValue(100).range(20, 300).sliderRange(20, 200).build());

    private final Setting<Boolean> advanced = sg.add(new BoolSetting.Builder()
        .name("advanced")
        .description("Show all the rare settings too.")
        .defaultValue(false).build());

    private final Setting<Order> order = sg.add(new EnumSetting.Builder<Order>()
        .name("order")
        .description("Auto: from where you stand (above the area: top to bottom; below it: bottom to top; inside it: the layers around your feet first, then upward). Nearest: the closest block. BottomUp / TopDown: layer by layer. TwoLayersThenUp: the lowest two layers of the area first, then upward.")
        .defaultValue(Order.Auto).visible(() -> advanced.get()).build());

    private final Setting<Boolean> autoTool = sg.add(new BoolSetting.Builder()
        .name("auto-tool")
        .description("Use the hotbar tool that mines the current block fastest.")
        .defaultValue(true).visible(() -> advanced.get()).build());

    private final Setting<Boolean> stopLowTool = sg.add(new BoolSetting.Builder()
        .name("stop-on-low-durability")
        .description("Stop when the tool in your hand has 2 or fewer uses left.")
        .defaultValue(true).visible(() -> advanced.get()).build());

    private final Setting<Integer> maxBlockTime = sg.add(new IntSetting.Builder()
        .name("max-block-time")
        .description("Skip a block that is still not broken after this long, in ms.")
        .defaultValue(6000).range(500, 30000).sliderRange(1000, 15000).visible(() -> advanced.get()).build());

    private final Setting<ZoneMode> zoneMode = sg.add(new EnumSetting.Builder<ZoneMode>()
        .name("zones")
        .description("Preset: the area is cut into fixed zones of the size you usually mine from one spot; it empties one zone, then goes to the next, and the camera sweeps from block to block. Auto: it just stands where the most blocks can be reached.")
        .defaultValue(ZoneMode.Preset).build());

    private final Setting<Integer> zoneWidth = sg.add(new IntSetting.Builder()
        .name("zone-width")
        .description("Zone size along X, in blocks (6 = what your recording showed). The zone always covers the whole height of the area.")
        .defaultValue(6).range(2, 30).sliderRange(2, 15).visible(() -> zoneMode.get() == ZoneMode.Preset).build());

    private final Setting<Integer> zoneLength = sg.add(new IntSetting.Builder()
        .name("zone-length")
        .description("Zone size along Z, in blocks (6 = what your recording showed).")
        .defaultValue(6).range(2, 30).sliderRange(2, 15).visible(() -> zoneMode.get() == ZoneMode.Preset).build());

    private final Setting<Integer> zoneDone = sg.add(new IntSetting.Builder()
        .name("zone-done-percent")
        .description("Go to the next zone when this much of the current one is mined.")
        .defaultValue(90).range(50, 100).sliderRange(50, 100).visible(() -> zoneMode.get() == ZoneMode.Preset).build());

    private final Setting<Integer> zonePause = sg.add(new IntSetting.Builder()
        .name("zone-pause")
        .description("Short pause when a zone is finished, before the next one, in ms.")
        .defaultValue(800).range(0, 5000).sliderRange(0, 3000).visible(() -> zoneMode.get() == ZoneMode.Preset).build());

    private final Setting<Boolean> debug = sg.add(new BoolSetting.Builder()
        .name("debug")
        .description("Say in chat why nothing is being mined (hidden behind other blocks, out of reach, skipped) and when the speed is lowered.")
        .defaultValue(false).build());

    // ---- Safety (for mining while you are away)

    private final Setting<Double> stopHealth = sgSafety.add(new DoubleSetting.Builder()
        .name("stop-on-low-health")
        .description("Stop when your health (hearts x 2) is at or below this. 0 = off. (Meteor's AutoLog can also log you out.)")
        .defaultValue(8.0).range(0.0, 36.0).sliderRange(0.0, 20.0).decimalPlaces(0).build());

    private final Setting<Integer> stopPlayerRadius = sgSafety.add(new IntSetting.Builder()
        .name("stop-when-player-near")
        .description("Stop when another player comes closer than this many blocks. 0 = off.")
        .defaultValue(0).range(0, 128).sliderRange(0, 64).build());

    // ---- Area

    private final Setting<Keybind> pos1Key = sgArea.add(new KeybindSetting.Builder()
        .name("corner-1-key")
        .description("Look at a block and press this key to set the first corner.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Keybind> pos2Key = sgArea.add(new KeybindSetting.Builder()
        .name("corner-2-key")
        .description("Look at the opposite corner block and press this key to set the second corner.")
        .defaultValue(Keybind.none()).build());

    private final Setting<Keybind> clearKey = sgArea.add(new KeybindSetting.Builder()
        .name("clear-selection-key")
        .description("Press this key to forget the selection.")
        .defaultValue(Keybind.none()).visible(() -> advanced.get()).build());

    private final Setting<Double> selectRange = sgArea.add(new DoubleSetting.Builder()
        .name("select-range")
        .description("How far away the block can be when you set a corner.")
        .defaultValue(32.0).range(4.0, 128.0).sliderRange(4.0, 64.0).decimalPlaces(0).visible(() -> advanced.get()).build());

    private final Setting<Boolean> showBox = sgArea.add(new BoolSetting.Builder()
        .name("show-box")
        .description("Draw the selected area.")
        .defaultValue(true).build());

    private final Setting<SettingColor> boxColor = sgArea.add(new ColorSetting.Builder()
        .name("box-color")
        .description("Colour of the selection box.")
        .defaultValue(new SettingColor(255, 80, 80, 255))
        .visible(showBox::get).build());

    // ---- Repeat

    private final Setting<Boolean> repeat = sgRepeat.add(new BoolSetting.Builder()
        .name("repeat")
        .description("When the area is empty, wait for it to respawn and mine it again.")
        .defaultValue(true).build());

    private final Setting<Integer> respawnPercent = sgRepeat.add(new IntSetting.Builder()
        .name("respawn-percent")
        .description("Start again once this share of the area's blocks (compared with the fullest it has been) is back.")
        .defaultValue(90).range(1, 100).sliderRange(1, 100)
        .visible(repeat::get).build());

    private final Setting<Integer> maxCycles = sgRepeat.add(new IntSetting.Builder()
        .name("max-cycles")
        .description("Stop after this many full clears. 0 = never stop.")
        .defaultValue(0).range(0, 1000).sliderRange(0, 100)
        .visible(repeat::get).build());

    // ---- Movement

    private final Setting<Boolean> reposition = sgMove.add(new BoolSetting.Builder()
        .name("reposition")
        .description("When nothing is in reach but blocks are left, walk to the closest spot from which the most remaining blocks can be reached, then carry on mining.")
        .defaultValue(true).build());

    private final Setting<Integer> repositionRadius = sgMove.add(new IntSetting.Builder()
        .name("search-radius")
        .description("How far around the nearest remaining block the module looks for a place to stand, in blocks.")
        .defaultValue(4).range(1, 8).sliderRange(1, 8)
        .visible(reposition::get).build());

    private final Setting<Integer> walkTimeout = sgMove.add(new IntSetting.Builder()
        .name("walk-timeout")
        .description("Give up a walk that takes longer than this, in ms.")
        .defaultValue(6000).range(1000, 20000).sliderRange(1000, 10000)
        .visible(reposition::get).build());

    // ---- Items

    private final Setting<List<Block>> skipBlocks = sgItems.add(new BlockListSetting.Builder()
        .name("skip-blocks")
        .description("Blocks that are never mined (for example ancient debris, if you only want the netherite blocks in your inventory).")
        .defaultValue(new ArrayList<>()).visible(() -> advanced.get()).build());

    private final Setting<Boolean> autoDrop = sgItems.add(new BoolSetting.Builder()
        .name("auto-drop")
        .description("Drop chosen items automatically once you hold enough stacks of them.")
        .defaultValue(false).build());

    private final Setting<List<Item>> dropItems = sgItems.add(new ItemListSetting.Builder()
        .name("drop-items")
        .description("The items to drop.")
        .defaultValue(new ArrayList<>())
        .visible(autoDrop::get).build());

    private final Setting<Integer> dropStacks = sgItems.add(new IntSetting.Builder()
        .name("drop-after-stacks")
        .description("Drop an item as soon as you hold this many stacks of it (everything of that item in your inventory is dropped).")
        .defaultValue(5).range(1, 36).sliderRange(1, 36)
        .visible(autoDrop::get).build());

    private final Setting<Boolean> dropOpenInventory = sgItems.add(new BoolSetting.Builder()
        .name("open-inventory-to-drop")
        .description("On: the inventory screen opens while dropping. Off: the items are dropped without opening it.")
        .defaultValue(false)
        .visible(autoDrop::get).build());

    private final Setting<Boolean> stopWhenFull = sgItems.add(new BoolSetting.Builder()
        .name("stop-when-inventory-full")
        .description("Stop when your inventory has no empty slot left.")
        .defaultValue(true).build());

    // ---- State

    private BlockPos corner1, corner2;
    private final List<BlockPos> targets = new ArrayList<>();
    private final Set<BlockPos> skipped = new HashSet<>();
    private Stage stage = Stage.MINING;
    private BlockPos current;
    private long currentStart, lastScan, lastReachMessage;
    private int cycles, baseline;
    private boolean aiming;
    private long rotStart;
    private float startYaw, startPitch, aimYaw, aimPitch;
    private BlockPos standSpot;
    private Order effOrder = Order.BottomUp;
    private double calmDuration = 80;
    private final Map<BlockPos, Vec3> visCache = new HashMap<>();
    private long lastDropCheck, dropAt, cycleStart;
    private int broken;
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    private int dropPhase;
    private final List<Integer> dropSlots = new ArrayList<>();
    private long walkStart, walkBlockedUntil;
    private int walkFailures;
    private int effBudget;
    private int curZx = -1, curZz = -1, zoneInitial, zoneStopAt;
    private long zonePauseUntil, nextBlockAt, lastZoneCheck;
    private final java.util.Set<Long> doneZones = new java.util.HashSet<>();
    private long lastBack, lastDebug, pathStartedAt;
    private boolean pathStarted;
    private BlockPos stickyFor;
    private Vec3 stickyPoint;
    private boolean walking;
    private int sweepDir = 1;
    private BlockPos lastHit;
    private long hitSince;

    public AreaMiner() {
        super(ItzTechnoGuyAddon.CATEGORY, "area-miner", "Mines everything inside a box you mark, and again after it respawns. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        if (client.player == null || client.level == null) {
            toggle();
            return;
        }
        if (corner1 == null || corner2 == null) {
            error("Set both corners first (look at a block and press the corner keys).");
            toggle();
            return;
        }
        long volume = volume();
        if (volume > MAX_VOLUME) {
            error("The area is too big (" + volume + " blocks, the limit is " + MAX_VOLUME + ").");
            toggle();
            return;
        }

        cycles = 0;
        baseline = 0;
        current = null;
        aiming = false;
        skipped.clear();
        standSpot = null;
        walkBlockedUntil = 0;
        walkFailures = 0;
        walking = false;
        sweepDir = 1;
        lastHit = null;
        stickyFor = null;
        stickyPoint = null;
        pathStarted = false;
        dropPhase = 0;
        lastDropCheck = 0;
        attempts.clear();
        broken = 0;
        cycleStart = System.currentTimeMillis();
        stage = Stage.MINING;
        int count = rebuildTargets();
        baseline = count;
        doneZones.clear();
        curZx = -1;
        curZz = -1;
        zonePauseUntil = 0;
        if (zoneMode.get() == ZoneMode.Preset) pickZone();
        info("Mining " + count + " block(s).");
    }

    @Override
    public void onDeactivate() {
        if (client.gameMode != null) client.gameMode.stopDestroyBlock();
        walking = false;
        releaseAll();
        current = null;
        aiming = false;
    }

    // ---------------------------------------------------------------- selection (called by Overlay)

    public void onGlobalKey(int key, int modifiers) {
        if (client.player == null || client.level == null || client.screen != null) return;

        if (pos1Key.get().isSet() && pos1Key.get().matches(true, key, modifiers)) {
            BlockPos p = lookedAtBlock();
            if (p == null) return;
            corner1 = p;
            info("Corner 1: " + p.getX() + " " + p.getY() + " " + p.getZ() + sizeText());
        } else if (pos2Key.get().isSet() && pos2Key.get().matches(true, key, modifiers)) {
            BlockPos p = lookedAtBlock();
            if (p == null) return;
            corner2 = p;
            info("Corner 2: " + p.getX() + " " + p.getY() + " " + p.getZ() + sizeText());
        } else if (clearKey.get().isSet() && clearKey.get().matches(true, key, modifiers)) {
            corner1 = null;
            corner2 = null;
            info("Selection cleared.");
        }
    }

    private BlockPos lookedAtBlock() {
        HitResult hit = client.player.pick(selectRange.get(), 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            warning("Look at a block first.");
            return null;
        }
        return ((BlockHitResult) hit).getBlockPos();
    }

    private String sizeText() {
        if (corner1 == null || corner2 == null) return "";
        int sx = Math.abs(corner1.getX() - corner2.getX()) + 1;
        int sy = Math.abs(corner1.getY() - corner2.getY()) + 1;
        int sz = Math.abs(corner1.getZ() - corner2.getZ()) + 1;
        return " (area " + sx + " x " + sy + " x " + sz + ")";
    }

    private long volume() {
        long sx = Math.abs(corner1.getX() - corner2.getX()) + 1L;
        long sy = Math.abs(corner1.getY() - corner2.getY()) + 1L;
        long sz = Math.abs(corner1.getZ() - corner2.getZ()) + 1L;
        return sx * sy * sz;
    }

    /** Draws the selected area (works even when the module is off). */
    public void renderSelection(Render3DEvent event) {
        if (!showBox.get() || corner1 == null || corner2 == null) return;

        double x1 = Math.min(corner1.getX(), corner2.getX()), x2 = Math.max(corner1.getX(), corner2.getX()) + 1.0;
        double y1 = Math.min(corner1.getY(), corner2.getY()), y2 = Math.max(corner1.getY(), corner2.getY()) + 1.0;
        double z1 = Math.min(corner1.getZ(), corner2.getZ()), z2 = Math.max(corner1.getZ(), corner2.getZ()) + 1.0;
        SettingColor c = boxColor.get();

        event.renderer.line(x1, y1, z1, x2, y1, z1, c);
        event.renderer.line(x2, y1, z1, x2, y1, z2, c);
        event.renderer.line(x2, y1, z2, x1, y1, z2, c);
        event.renderer.line(x1, y1, z2, x1, y1, z1, c);
        event.renderer.line(x1, y2, z1, x2, y2, z1, c);
        event.renderer.line(x2, y2, z1, x2, y2, z2, c);
        event.renderer.line(x2, y2, z2, x1, y2, z2, c);
        event.renderer.line(x1, y2, z2, x1, y2, z1, c);
        event.renderer.line(x1, y1, z1, x1, y2, z1, c);
        event.renderer.line(x2, y1, z1, x2, y2, z1, c);
        event.renderer.line(x2, y1, z2, x2, y2, z2, c);
        event.renderer.line(x1, y1, z2, x1, y2, z2, c);
    }

    // ---------------------------------------------------------------- targets

    private boolean mineable(BlockPos pos) {
        BlockState state = client.level.getBlockState(pos);
        if (state.isAir() || state.getBlock() instanceof LiquidBlock) return false;
        if (state.getDestroySpeed(client.level, pos) < 0) return false;   // bedrock and the like
        if (skipBlocks.get().contains(state.getBlock())) return false;
        return !skipped.contains(pos);
    }

    private boolean inArea(BlockPos p) {
        return p.getX() >= Math.min(corner1.getX(), corner2.getX()) && p.getX() <= Math.max(corner1.getX(), corner2.getX())
            && p.getY() >= Math.min(corner1.getY(), corner2.getY()) && p.getY() <= Math.max(corner1.getY(), corner2.getY())
            && p.getZ() >= Math.min(corner1.getZ(), corner2.getZ()) && p.getZ() <= Math.max(corner1.getZ(), corner2.getZ());
    }

    private boolean zonesOn() {
        return zoneMode.get() == ZoneMode.Preset && curZx >= 0;
    }

    private boolean inZone(BlockPos p) {
        if (!zonesOn()) return true;
        int minX = Math.min(corner1.getX(), corner2.getX()), minZ = Math.min(corner1.getZ(), corner2.getZ());
        return Math.floorDiv(p.getX() - minX, Math.max(1, zoneWidth.get())) == curZx
            && Math.floorDiv(p.getZ() - minZ, Math.max(1, zoneLength.get())) == curZz;
    }

    /** A block that can be mined now and belongs to the zone being worked on. */
    private boolean live(BlockPos p) {
        return mineable(p) && inZone(p);
    }

    private static long zoneKey(int zx, int zz) {
        return ((long) zx << 32) | (zz & 0xffffffffL);
    }

    /** Picks the nearest zone that still has blocks and is not already finished. */
    private boolean pickZone() {
        int minX = Math.min(corner1.getX(), corner2.getX()), minZ = Math.min(corner1.getZ(), corner2.getZ());
        int sx = Math.max(1, zoneWidth.get()), sz = Math.max(1, zoneLength.get());
        java.util.Map<Long, int[]> counts = new java.util.HashMap<>();
        for (BlockPos p : targets) {
            if (!mineable(p)) continue;
            int zx = Math.floorDiv(p.getX() - minX, sx), zz = Math.floorDiv(p.getZ() - minZ, sz);
            long key = zoneKey(zx, zz);
            if (doneZones.contains(key)) continue;
            counts.computeIfAbsent(key, k -> new int[]{zx, zz, 0})[2]++;
        }
        int[] best = null;
        double bestDist = Double.MAX_VALUE;
        for (int[] a : counts.values()) {
            double cx = minX + a[0] * sx + sx / 2.0, cz = minZ + a[1] * sz + sz / 2.0;
            double d = Math.hypot(client.player.getX() - cx, client.player.getZ() - cz);
            if (d < bestDist) {
                bestDist = d;
                best = a;
            }
        }
        if (best == null) {
            curZx = -1;
            curZz = -1;
            return false;
        }
        curZx = best[0];
        curZz = best[1];
        zoneInitial = best[2];
        zoneStopAt = (int) Math.floor(zoneInitial * (100 - zoneDone.get()) / 100.0);
        return true;
    }

    /** Marks the current zone as done and goes to the next one. False when there is none left. */
    private boolean switchZone(long now) {
        if (curZx >= 0) doneZones.add(zoneKey(curZx, curZz));
        client.gameMode.stopDestroyBlock();
        current = null;
        stickyFor = null;
        boolean found = pickZone();
        if (found) {
            zonePauseUntil = now + zonePause.get();
            if (debug.get()) info("Next zone: " + zoneInitial + " block(s).");
        }
        return found;
    }

    private double turnScore(BlockPos p, Vec3 eye, Vec3 look) {
        Vec3 dir = new Vec3(p.getX() + 0.5 - eye.x, p.getY() + 0.5 - eye.y, p.getZ() + 0.5 - eye.z);
        double len = dir.length();
        return len < 1.0e-6 ? 0 : 1.0 - look.dot(dir) / len;
    }

    /** Lists every mineable block in the area in the chosen order. Returns how many there are. */
    private int rebuildTargets() {
        targets.clear();

        int minX = Math.min(corner1.getX(), corner2.getX()), maxX = Math.max(corner1.getX(), corner2.getX());
        int minY = Math.min(corner1.getY(), corner2.getY()), maxY = Math.max(corner1.getY(), corner2.getY());
        int minZ = Math.min(corner1.getZ(), corner2.getZ()), maxZ = Math.max(corner1.getZ(), corner2.getZ());

        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (mineable(p)) targets.add(p);
                }
            }
        }

        final Vec3 eye = client.player.getEyePosition();
        final int low = minY;
        final int feetY = client.player.blockPosition().getY();
        Comparator<BlockPos> byDistance = Comparator.comparingDouble(p -> eye.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5));

        // Auto: eye above the area = dig down from the top; otherwise the two lowest layers first, then up.
        if (order.get() == Order.Auto) {
            effOrder = eye.y >= maxY + 1 ? Order.TopDown : Order.TwoLayersThenUp;
        } else {
            effOrder = order.get();
        }

        switch (effOrder) {
            case Auto -> targets.sort(Comparator
                .<BlockPos>comparingInt(p -> p.getY() <= feetY ? 0 : 1)
                .thenComparingInt(p -> p.getY() <= feetY ? -p.getY() : p.getY())
                .thenComparing(byDistance));
            case Nearest -> targets.sort(byDistance);
            case BottomUp -> targets.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY).thenComparing(byDistance));
            case TopDown -> targets.sort(Comparator.<BlockPos>comparingInt(p -> -p.getY()).thenComparing(byDistance));
            case TwoLayersThenUp -> targets.sort(Comparator
                .<BlockPos>comparingInt(p -> p.getY() <= low + 1 ? 0 : 1)
                .thenComparingInt(BlockPos::getY)
                .thenComparing(byDistance));
        }
        lastScan = System.currentTimeMillis();
        return targets.size();
    }

    private double reachNow() {
        return client.player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
    }

    private boolean inReach(BlockPos pos, Vec3 eye, double reach) {
        return new AABB(pos).distanceToSqr(eye) <= reach * reach;
    }

    /**
     * A point on a face of the block that you can really see from the eye (nothing in the way), or
     * null. Blocks hidden behind other blocks are never targeted, so with stone in front and
     * deepslate behind it only the stone is mined until it is gone. Cached for the current tick.
     */
    private Vec3 visiblePoint(BlockPos pos, Vec3 eye) {
        if (visCache.containsKey(pos)) return visCache.get(pos);
        Vec3 found = computeVisible(pos, eye, true);
        visCache.put(pos, found);
        return found;
    }

    /**
     * Looks at every face that turns toward {@code eye} and is not covered. With {@code crosshair} the
     * aim point is the spot of the face closest to where the camera already looks (so the camera
     * moves as little as possible and never needs the exact middle of the block); otherwise the middle
     * of the face is used (cheaper, for scoring places to stand). Returns null when nothing is visible.
     */
    private Vec3 computeVisible(BlockPos pos, Vec3 eye, boolean crosshair) {
        Vec3 c = Vec3.atCenterOf(pos);
        Vec3 look = client.player.getLookAngle();
        Vec3 found = null;
        double bestScore = Double.MAX_VALUE;

        for (Direction d : Direction.values()) {
            if ((eye.x - c.x) * d.getStepX() + (eye.y - c.y) * d.getStepY() + (eye.z - c.z) * d.getStepZ() <= 0) continue;
            BlockPos n = pos.relative(d);
            if (client.level.getBlockState(n).isFaceSturdy(client.level, n, d.getOpposite())) continue;   // covered

            Vec3 p = crosshair ? facePoint(c, d, eye, look) : faceCenter(c, d);
            if (!sees(pos, eye, p)) {
                if (!crosshair) continue;
                p = faceCenter(c, d);
                if (!sees(pos, eye, p)) continue;
            }
            // Of the visible faces take the one that needs the least turning.
            Vec3 dir = p.subtract(eye);
            double len = dir.length();
            double score = len < 1.0e-6 ? 0 : 1.0 - look.dot(dir) / len;
            if (score < bestScore) {
                bestScore = score;
                found = p;
            }
        }
        return found;
    }

    private boolean sees(BlockPos pos, Vec3 eye, Vec3 p) {
        BlockHitResult hit = client.level.clip(new ClipContext(eye, p, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, client.player));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos);
    }

    private Vec3 faceCenter(Vec3 c, Direction d) {
        return new Vec3(c.x + d.getStepX() * 0.49, c.y + d.getStepY() * 0.49, c.z + d.getStepZ() * 0.49);
    }

    /** The point of the face where the camera ray crosses it, pushed inside the face (0.1 from the edge). */
    private Vec3 facePoint(Vec3 c, Direction d, Vec3 eye, Vec3 look) {
        double[] cc = {c.x, c.y, c.z};
        double[] e = {eye.x, eye.y, eye.z};
        double[] l = {look.x, look.y, look.z};
        int axis = d.getAxis().ordinal();   // X=0, Y=1, Z=2
        double plane = cc[axis] + 0.5 * (axis == 0 ? d.getStepX() : axis == 1 ? d.getStepY() : d.getStepZ());
        double[] q = {cc[0], cc[1], cc[2]};
        if (Math.abs(l[axis]) > 1.0e-6) {
            double t = (plane - e[axis]) / l[axis];
            if (t > 0) {
                for (int k = 0; k < 3; k++) q[k] = e[k] + l[k] * t;
            }
        }
        for (int k = 0; k < 3; k++) {
            q[k] = k == axis ? cc[axis] + 0.49 * Math.signum(plane - cc[axis]) : Mth.clamp(q[k], cc[k] - 0.4, cc[k] + 0.4);
        }
        return new Vec3(q[0], q[1], q[2]);
    }

    /** The aim point of the block being mined: chosen once and kept while it stays visible, so the camera does not restart every tick. */
    private Vec3 stickyAim(BlockPos pos, Vec3 eye) {
        if (pos.equals(stickyFor) && stickyPoint != null && sees(pos, eye, stickyPoint)) return stickyPoint;
        stickyFor = pos;
        stickyPoint = visiblePoint(pos, eye);
        return stickyPoint;
    }

    /**
     * The next block to aim at: the visible, reachable block of the zone that needs the least turning
     * from where the crosshair is now, keeping the sweep going the same way (left or right) while there
     * are blocks that way, then coming back, like sweeping the crosshair over a wall by hand.
     */
    private BlockPos nextTarget(Vec3 eye, double reach) {
        Vec3 look = client.player.getLookAngle();
        float curYaw = client.player.getYRot();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE, bestDy = 0;

        for (BlockPos p : targets) {
            if (!live(p) || !inReach(p, eye, reach) || visiblePoint(p, eye) == null) continue;
            double dy = Mth.wrapDegrees(Rotations.getYaw(new Vec3(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5)) - curYaw);
            double score = turnScore(p, eye, look) + (dy * sweepDir < 0 ? 0.04 : 0.0);
            if (score < bestScore) {
                bestScore = score;
                best = p;
                bestDy = dy;
            }
        }
        if (best != null && Math.abs(bestDy) > 1.0) sweepDir = bestDy > 0 ? 1 : -1;
        return best;
    }

    private int remainingCount() {
        int n = 0;
        for (BlockPos p : targets) {
            if (live(p)) n++;
        }
        return n;
    }

    // ---------------------------------------------------------------- mining loop

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        long now = System.currentTimeMillis();
        visCache.clear();

        if (!client.player.isAlive()) {
            toggle();
            return;
        }
        if (stopHealth.get() > 0 && client.player.getHealth() + client.player.getAbsorptionAmount() <= stopHealth.get()) {
            warning("Your health is low, stopping.");
            toggle();
            return;
        }
        if (stopPlayerRadius.get() > 0) {
            for (Player other : client.level.players()) {
                if (other != client.player && other.distanceTo(client.player) <= stopPlayerRadius.get()) {
                    warning(other.getName().getString() + " is near, stopping.");
                    toggle();
                    return;
                }
            }
        }

        dropTick(now);
        if (dropPhase != 0) {   // the drop (with the inventory screen) is in progress
            releaseAll();
            return;
        }

        if (stage == Stage.WAIT_RESPAWN) {
            waitForRespawn(now);
            return;
        }
        if (client.screen != null) {   // not while an inventory or chest is open
            releaseAll();
            return;
        }
        if (stopWhenFull.get() && !hasFreeSlot()) {
            info("Your inventory is full, stopping.");
            toggle();
            return;
        }

        if (stopLowTool.get()) {
            ItemStack held = client.player.getMainHandItem();
            if (held.isDamageableItem() && held.getMaxDamage() - held.getDamageValue() <= 2) {
                warning("Your tool is almost broken, stopping.");
                toggle();
                return;
            }
        }

        Vec3 eye = client.player.getEyePosition();
        double reach = reachNow();

        if (walking) walkStep(now);

        // Next zone?
        if (zonesOn() && now - lastZoneCheck > 250) {
            lastZoneCheck = now;
            if (remainingCount() <= zoneStopAt && switchZone(now)) {
                client.options.keyAttack.setDown(false);
                return;
            }
        }
        if (now < zonePauseUntil) {
            client.options.keyAttack.setDown(false);
            return;
        }

        // What is under the crosshair? Only that is ever mined, and only by holding the attack key.
        if (lastHit != null && !mineable(lastHit)) {
            broken++;
            lastHit = null;
        }
        BlockPos hit = null;
        if (client.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) hit = bhr.getBlockPos();
        boolean hitLive = hit != null && inArea(hit) && mineable(hit);
        boolean slowHit = false;
        if (hitLive) {
            BlockState hs = client.level.getBlockState(hit);
            if (!hit.equals(lastHit)) {
                lastHit = hit;
                hitSince = now;
                if (autoTool.get()) selectBestTool(hs);
            } else if (now - hitSince > maxBlockTime.get()) {
                warning("Skipping a block that does not break.");
                skipped.add(hit);
                hitLive = false;
                lastHit = null;
            }
            slowHit = hitLive && hs.getDestroyProgress(client.player, client.level, hit) < 1.0F;
        }
        client.options.keyAttack.setDown(hitLive);
        if (slowHit) return;   // like a hand: the crosshair stays on a slow block until it breaks

        // Where to aim next.
        if (current != null && (!live(current) || !inReach(current, eye, reach) || visiblePoint(current, eye) == null)) current = null;
        if (current != null && now - currentStart > maxBlockTime.get() + 1500) {   // the crosshair never got it
            skipped.add(current);
            current = null;
        }
        if (current == null) {
            current = nextTarget(eye, reach);
            currentStart = now;
        }
        if (current == null) {
            int left = remainingCount();
            if (left == 0) {
                releaseAll();
                areaCleared();
                return;
            }
            if (debug.get() && now - lastDebug > 2000) {
                lastDebug = now;
                debugWhy(eye, reach, left);
            }
            if (!walking) {
                if (reposition.get() && now >= walkBlockedUntil && startWalk(eye)) {
                    if (!isActive()) return;
                } else if (now - lastReachMessage > 3000) {
                    lastReachMessage = now;
                    warning(left + " block(s) are out of your reach. Move closer.");
                }
            }
            if (walking && standSpot != null) {   // look where we walk
                double gdx = standSpot.getX() + 0.5 - client.player.getX(), gdz = standSpot.getZ() + 0.5 - client.player.getZ();
                turnTo((float) Mth.wrapDegrees(Math.toDegrees(Math.atan2(gdz, gdx)) - 90.0), 10.0f);
            }
            return;
        }

        Vec3 point = stickyAim(current, eye);
        if (point == null) {
            current = null;
            return;
        }
        aimAt(point);
    }

    private void debugWhy(Vec3 eye, double reach, int left) {
        int far = 0, hidden = 0;
        BlockPos firstHidden = null;
        for (BlockPos p : targets) {
            if (!live(p)) continue;
            if (!inReach(p, eye, reach)) far++;
            else if (visiblePoint(p, eye) == null) {
                hidden++;
                if (firstHidden == null) firstHidden = p;
            }
        }
        info("Nothing to mine now: " + left + " left, " + far + " out of reach, " + hidden + " in reach but hidden behind other blocks"
            + (firstHidden != null ? " (e.g. " + firstHidden.toShortString() + ")" : "") + ", " + skipped.size() + " skipped.");
    }

    private boolean hasFreeSlot() {
        for (int i = 0; i < 36; i++) {
            if (client.player.getInventory().getItem(i).isEmpty()) return true;
        }
        return false;
    }

    /** Drops the chosen items once enough stacks of them are in the inventory. */
    private void dropTick(long now) {
        if (dropPhase == 1) {
            if (now < dropAt) return;
            for (int slot : dropSlots) InvUtils.drop().slot(slot);
            dropSlots.clear();
            dropPhase = 2;
            dropAt = now + 60;
            return;
        }
        if (dropPhase == 2) {
            if (now < dropAt) return;
            if (client.screen instanceof InventoryScreen) client.player.closeContainer();
            dropPhase = 0;
            return;
        }

        if (!autoDrop.get() || now - lastDropCheck < 500) return;
        lastDropCheck = now;
        if (client.screen != null || InvSession.busy() || dropItems.get().isEmpty()) return;

        dropSlots.clear();
        for (Item item : dropItems.get()) {
            int count = 0, max = new ItemStack(item).getMaxStackSize();
            List<Integer> slots = new ArrayList<>();
            for (int i = 0; i < 36; i++) {
                ItemStack s = client.player.getInventory().getItem(i);
                if (!s.is(item)) continue;
                count += s.getCount();
                slots.add(i);
            }
            if (count >= (long) dropStacks.get() * max) dropSlots.addAll(slots);
        }
        if (dropSlots.isEmpty()) return;

        if (dropOpenInventory.get()) {
            client.setScreen(new InventoryScreen(client.player));
            dropPhase = 1;
            dropAt = now + 50;
        } else {
            for (int slot : dropSlots) InvUtils.drop().slot(slot);
            dropSlots.clear();
        }
    }

    private void areaCleared() {
        cycles++;
        long took = Math.max(1, System.currentTimeMillis() - cycleStart);
        info("Area cleared (" + cycles + "): " + broken + " block(s) in " + took + " ms ("
            + Math.round(broken * 1000.0 / took * 10) / 10.0 + " blocks/s).");
        attempts.clear();
        if (!repeat.get() || (maxCycles.get() > 0 && cycles >= maxCycles.get())) {
            toggle();
            return;
        }
        skipped.clear();
        stage = Stage.WAIT_RESPAWN;
        lastScan = 0;
    }

    private void waitForRespawn(long now) {
        if (now - lastScan < 250) return;
        int count = rebuildTargets();
        baseline = Math.max(baseline, count);
        int needed = Math.max(1, (int) Math.ceil(baseline * respawnPercent.get() / 100.0));
        if (count >= needed) {
            info("The area respawned (" + count + " block(s)), mining again.");
            doneZones.clear();
            if (zoneMode.get() == ZoneMode.Preset) pickZone();
            stage = Stage.MINING;
            current = null;
            broken = 0;
            cycleStart = now;
        }
    }

    private void selectBestTool(BlockState state) {
        int best = -1;
        float bestSpeed = 0f;
        for (int i = 0; i < 9; i++) {
            ItemStack s = client.player.getInventory().getItem(i);
            float speed = s.getDestroySpeed(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = i;
            }
        }
        if (best < 0) return;
        if (client.player.getInventory().getItem(best) == client.player.getMainHandItem()) return;
        InvUtils.swap(best, false);
    }

    // ---------------------------------------------------------------- walking to a better spot

    /** Picks a place to stand from which more of the remaining blocks are reachable and starts walking there. */
    private boolean startWalk(Vec3 eye) {
        standSpot = findStandSpot(eye);
        if (standSpot == null) {
            walkBlockedUntil = System.currentTimeMillis() + 3000;
            return false;
        }
        if (walkFailures >= 3) {
            warning("Walking did not help three times in a row, stopping.");
            toggle();
            return true;
        }
        walking = true;
        walkStart = System.currentTimeMillis();
        return true;
    }

    private BlockPos findStandSpot(Vec3 eye) {
        BlockPos nearest = null;
        double nearestDist = Double.MAX_VALUE;
        List<BlockPos> remaining = new ArrayList<>();
        for (BlockPos p : targets) {
            if (!live(p)) continue;
            remaining.add(p);
            double d = eye.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
            if (d < nearestDist) {
                nearestDist = d;
                nearest = p;
            }
        }
        if (nearest == null) return null;

        double reach = reachNow();
        final BlockPos around = nearest;
        remaining.sort(Comparator.comparingDouble(q -> q.distSqr(around)));
        if (remaining.size() > 40) remaining = new ArrayList<>(remaining.subList(0, 40));
        BlockPos here = client.player.blockPosition();
        int r = repositionRadius.get();
        BlockPos best = null;
        int bestScore = 0;
        double bestDist = Double.MAX_VALUE;
        double px = client.player.getX(), pz = client.player.getZ();

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -3; dy <= 1; dy++) {
                    BlockPos feet = nearest.offset(dx, dy, dz);
                    if (!standable(feet) || feet.equals(here)) continue;
                    Vec3 e = new Vec3(feet.getX() + 0.5, feet.getY() + 1.62, feet.getZ() + 0.5);
                    int score = 0;
                    for (BlockPos q : remaining) {
                        if (inReach(q, e, reach) && computeVisible(q, e, false) != null) score++;
                    }
                    if (score == 0) continue;
                    double dist = Math.hypot(feet.getX() + 0.5 - px, feet.getZ() + 0.5 - pz);
                    if (score > bestScore || (score == bestScore && dist < bestDist)) {
                        best = feet;
                        bestScore = score;
                        bestDist = dist;
                    }
                }
            }
        }
        return best;
    }

    /** A cell you can stand in: free feet and head space, solid floor, no liquid or fire. */
    private boolean standable(BlockPos feet) {
        BlockPos head = feet.above();
        BlockPos floor = feet.below();
        if (!client.level.getBlockState(feet).getCollisionShape(client.level, feet).isEmpty()) return false;
        if (!client.level.getBlockState(head).getCollisionShape(client.level, head).isEmpty()) return false;
        if (!client.level.getFluidState(feet).isEmpty() || !client.level.getFluidState(head).isEmpty()) return false;
        return client.level.getBlockState(floor).isFaceSturdy(client.level, floor, Direction.UP);
    }

    /** One step ahead is safe when it has ground within two blocks and no liquid. */
    private boolean safeStep(BlockPos feet) {
        if (!client.level.getFluidState(feet).isEmpty()) return false;
        for (int d = 1; d <= 2; d++) {
            BlockPos below = feet.below(d);
            if (client.level.getBlockState(below).isFaceSturdy(client.level, below, Direction.UP)) return true;
        }
        return false;
    }

    /** Walks to the stand spot with the movement keys only; the camera is left to the mining, like a player who walks sideways while sweeping. */
    private void walkStep(long now) {
        if (standSpot == null) {
            walking = false;
            return;
        }
        double dx = standSpot.getX() + 0.5 - client.player.getX(), dz = standSpot.getZ() + 0.5 - client.player.getZ();
        double dist = Math.hypot(dx, dz);
        boolean arrived = dist < 0.5 && Math.abs(client.player.getY() - standSpot.getY()) < 1.5;
        if (arrived || now - walkStart > walkTimeout.get()) {
            releaseMove();
            walking = false;
            if (arrived) {
                walkFailures = 0;
            } else {
                walkFailures++;
                warning("Could not reach the spot in time.");
            }
            return;
        }

        double nx = dx / Math.max(dist, 1.0e-6), nz = dz / Math.max(dist, 1.0e-6);
        BlockPos ahead = BlockPos.containing(client.player.getX() + nx * 0.9, client.player.getY(), client.player.getZ() + nz * 0.9);
        if (!safeStep(ahead)) {
            releaseMove();
            walking = false;
            walkFailures++;
            walkBlockedUntil = now + 3000;
            warning("It is not safe to walk on (a drop or liquid ahead), stopped.");
            return;
        }

        float goalYaw = (float) Mth.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float rel = Mth.wrapDegrees(goalYaw - client.player.getYRot());   // > 0: the goal is to the right
        float a = Math.abs(rel);
        boolean forward = a < 67.5f;
        client.options.keyUp.setDown(forward);
        client.options.keyDown.setDown(a > 112.5f);
        client.options.keyRight.setDown(rel > 22.5f && rel < 157.5f);
        client.options.keyLeft.setDown(rel < -22.5f && rel > -157.5f);
        client.options.keySprint.setDown(forward && a < 45f);
        client.options.keyJump.setDown(client.player.horizontalCollision && client.player.onGround());
    }

    private void releaseMove() {
        if (client.options == null) return;
        client.options.keyUp.setDown(false);
        client.options.keyDown.setDown(false);
        client.options.keyLeft.setDown(false);
        client.options.keyRight.setDown(false);
        client.options.keySprint.setDown(false);
        client.options.keyJump.setDown(false);
    }

    private void releaseAll() {
        releaseMove();
        if (client.options != null) client.options.keyAttack.setDown(false);
    }

    // ---------------------------------------------------------------- camera

    private void aimAt(Vec3 point) {
        turnTo((float) Rotations.getYaw(point), Mth.clamp((float) Rotations.getPitch(point), -90f, 90f));
    }

    /** Turns the camera at the sweep speed (smooth start and stop), without restarting for tiny changes. */
    private void turnTo(float yaw, float pitch) {
        float curYaw = aiming ? aimYaw : client.player.getYRot();
        float curPitch = aiming ? aimPitch : client.player.getXRot();
        double diff = Math.hypot(Mth.wrapDegrees(yaw - curYaw), pitch - curPitch);
        if (aiming && diff < 0.8) return;
        double degPerSec = 260.0 * speed.get() / 100.0;
        calmDuration = 40.0 + diff / degPerSec * 1000.0;
        startAim(yaw, pitch);
    }

    private void startAim(float yaw, float pitch) {
        if (aiming && Math.abs(Mth.wrapDegrees(yaw - aimYaw)) < 0.5f && Math.abs(pitch - aimPitch) < 0.5f) return;

        aimYaw = yaw;
        aimPitch = pitch;
        startYaw = client.player.getYRot();
        startPitch = client.player.getXRot();
        rotStart = System.currentTimeMillis();
        aiming = true;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!aiming || client.player == null) return;

        double duration = calmDuration;
        double t = duration > 0 ? Math.min(1.0, (System.currentTimeMillis() - rotStart) / duration) : 1.0;
        double e = t * t * (3.0 - 2.0 * t);

        float yaw = startYaw + Mth.wrapDegrees(aimYaw - startYaw) * (float) e;
        float pitch = Mth.clamp(startPitch + (aimPitch - startPitch) * (float) e, -90f, 90f);
        client.player.setYRot(yaw);
        client.player.setXRot(pitch);
        client.player.yRotO = yaw;
        client.player.xRotO = pitch;
    }
}
