package com.itztechnoguy.addon.modules;

import net.minecraft.core.BlockPos;

import java.lang.reflect.Method;

/**
 * Walks with Meteor's own path manager (Baritone) when it is there. It is called by reflection so
 * the addon still builds and runs when that API looks different: every call just returns false and
 * the caller falls back to its own walking.
 */
final class BaritoneMove {
    private BaritoneMove() { }

    private static Object manager() {
        try {
            Class<?> cls = Class.forName("meteordevelopment.meteorclient.pathing.PathManagers");
            Object m = cls.getMethod("get").invoke(null);
            if (m == null || m.getClass().getSimpleName().contains("Nop")) return null;
            return m;
        } catch (Throwable t) {
            return null;
        }
    }

    static boolean available() {
        return manager() != null;
    }

    static boolean moveTo(BlockPos pos) {
        try {
            Object m = manager();
            if (m == null) return false;
            Method mt = m.getClass().getMethod("moveTo", BlockPos.class, boolean.class);
            mt.invoke(m, pos, false);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean isPathing() {
        try {
            Object m = manager();
            if (m == null) return false;
            return (boolean) m.getClass().getMethod("isPathing").invoke(m);
        } catch (Throwable t) {
            return false;
        }
    }

    static void stop() {
        try {
            Object m = manager();
            if (m != null) m.getClass().getMethod("stop").invoke(m);
        } catch (Throwable t) {
            // nothing to stop
        }
    }
}
