package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.sounds.SoundSource;

/**
 * AFK Adjustments by ItzTechnoGuy: uses as little of the phone as possible while you stand AFK.
 * The world is only drawn once every frame-interval (1000 ms = 1 FPS, 60000 ms = 1 frame a minute);
 * all the other frames are skipped completely. The game keeps running (it still has to receive
 * the server's packets and tick the world), but there is almost no drawing work. The render and
 * simulation distances, particles and sound are lowered too. Switching the module off puts
 * every setting back. Turn on Meteor's AntiAFK as well if the server kicks idle players.
 */
public class AfkAdjustments extends Module {
    /** How long a frame is allowed through once it is due (the game draws about 10 times a second at the lowest FPS limit). */
    private static final long WINDOW_MS = 150;

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> frameInterval = sg.add(new IntSetting.Builder()
        .name("frame-interval")
        .description("Draw one frame every this many ms. 1000 = 1 FPS, 60000 = one frame a minute. Everything in between is not drawn at all.")
        .defaultValue(1000).range(100, 600000).sliderRange(100, 60000).build());

    private final Setting<Boolean> drawWithScreen = sg.add(new BoolSetting.Builder()
        .name("draw-with-screen")
        .description("Draw normally while a menu or the chat is open, so you can use them.")
        .defaultValue(true).build());

    private final Setting<Integer> fpsLimit = sg.add(new IntSetting.Builder()
        .name("fps-limit")
        .description("Highest FPS the game loop may run at (10 is the lowest the game allows). Lower = less work.")
        .defaultValue(10).range(10, 60).sliderRange(10, 60).build());

    private final Setting<Integer> renderDistance = sg.add(new IntSetting.Builder()
        .name("render-distance")
        .description("Render distance in chunks while AFK (2 is the lowest). The server then also sends fewer chunks.")
        .defaultValue(2).range(2, 32).sliderRange(2, 16).build());

    private final Setting<Integer> simulationDistance = sg.add(new IntSetting.Builder()
        .name("simulation-distance")
        .description("Simulation distance in chunks while AFK (5 is the lowest).")
        .defaultValue(5).range(5, 32).sliderRange(5, 16).build());

    private final Setting<Boolean> minimalParticles = sg.add(new BoolSetting.Builder()
        .name("minimal-particles")
        .description("Set particles to Minimal (particles still cost work even when nothing is drawn).")
        .defaultValue(true).build());

    private final Setting<Boolean> mute = sg.add(new BoolSetting.Builder()
        .name("mute")
        .description("Master volume to 0 while AFK.")
        .defaultValue(true).build());

    private long lastFrame;
    private boolean saved;
    private int oldFps, oldRender, oldSim;
    private ParticleStatus oldParticles;
    private double oldVolume;

    public AfkAdjustments() {
        super(ItzTechnoGuyAddon.CATEGORY, "afk-adjustments", "Lowest possible phone usage while AFK: draws one frame every few seconds (or minutes) and lowers distances, particles and sound. Everything is restored when you switch it off. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        saved = false;
        if (client.options == null) {
            toggle();
            return;
        }
        oldFps = client.options.framerateLimit().get();
        oldRender = client.options.renderDistance().get();
        oldSim = client.options.simulationDistance().get();
        oldParticles = client.options.particles().get();
        oldVolume = client.options.getSoundSourceOptionInstance(SoundSource.MASTER).get();
        saved = true;
        lastFrame = System.currentTimeMillis();
        apply();
        info("AFK adjustments on: " + (frameInterval.get() >= 1000 ? (frameInterval.get() / 1000.0) + " s" : frameInterval.get() + " ms") + " between frames.");
    }

    @Override
    public void onDeactivate() {
        client.noRender = false;
        if (!saved || client.options == null) return;
        client.options.framerateLimit().set(oldFps);
        client.options.renderDistance().set(oldRender);
        client.options.simulationDistance().set(oldSim);
        client.options.particles().set(oldParticles);
        client.options.getSoundSourceOptionInstance(SoundSource.MASTER).set(oldVolume);
        saved = false;
        info("AFK adjustments off: settings restored.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!saved) return;
        apply();   // settings may have been changed in the module window

        long now = System.currentTimeMillis();
        long since = now - lastFrame;
        if (since >= frameInterval.get()) {
            lastFrame = now;
            since = 0;
        }
        boolean draw = since < WINDOW_MS || (drawWithScreen.get() && client.screen != null);
        client.noRender = !draw;
    }

    private void apply() {
        if (client.options.framerateLimit().get() != fpsLimit.get()) client.options.framerateLimit().set(fpsLimit.get());
        if (client.options.renderDistance().get() != renderDistance.get()) client.options.renderDistance().set(renderDistance.get());
        if (client.options.simulationDistance().get() != simulationDistance.get()) client.options.simulationDistance().set(simulationDistance.get());
        if (minimalParticles.get() && client.options.particles().get() != ParticleStatus.MINIMAL) client.options.particles().set(ParticleStatus.MINIMAL);
        if (mute.get() && client.options.getSoundSourceOptionInstance(SoundSource.MASTER).get() != 0.0) client.options.getSoundSourceOptionInstance(SoundSource.MASTER).set(0.0);
    }
}
