package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.server.level.ParticleStatus;
import net.minecraft.sounds.SoundSource;

import java.lang.reflect.Method;

/**
 * AFK Adjustments by ItzTechnoGuy: one switch for the lowest possible phone usage while standing AFK.
 * - The world is drawn only once every frame-interval (1000 ms = 1 FPS); all other frames are skipped.
 * - FPS limit 10, render distance 2, simulation distance 5, particles minimal, sound off.
 * - Memory: the JVM is told to give free heap back quickly and a garbage collection runs every 30 s.
 * Everything is put back when the module is switched off. Turn on Meteor's AntiAFK as well if the
 * server kicks idle players.
 */
public class AfkAdjustments extends Module {
    /** A frame is let through for this long once it is due (the game loop runs about 10 times a second). */
    private static final long WINDOW_MS = 150;
    private static final long GC_EVERY_MS = 30_000;

    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> frameInterval = sg.add(new IntSetting.Builder()
        .name("frame-interval")
        .description("Draw one frame every this many ms. 1000 = 1 FPS, 60000 = one frame a minute. Menus and chat are always drawn normally.")
        .defaultValue(1000).range(100, 600000).sliderRange(100, 60000).build());

    private long lastFrame, lastGc;
    private boolean saved;
    private int oldFps, oldRender, oldSim;
    private ParticleStatus oldParticles;
    private double oldVolume;
    private String oldMinFree, oldMaxFree;

    public AfkAdjustments() {
        super(ItzTechnoGuyAddon.CATEGORY, "afk-adjustments", "Lowest possible phone usage while AFK: one frame every few seconds, minimum distances, no sound and a smaller memory footprint. Everything is restored when you switch it off. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        saved = false;
        if (client.options == null) {
            toggle();
            return;
        }
        oldFps = client.options.framerateLimit().get();
        oldRender = client.options.renderDistance().get();
        oldSim = client.options.simulationDistance().get();
        oldParticles = client.options.particles().get();
        oldVolume = client.options.getSoundSourceOptionInstance(SoundSource.MASTER).get();
        saved = true;

        long now = System.currentTimeMillis();
        lastFrame = now;
        lastGc = now;
        apply();

        String before = heapText();
        oldMinFree = getFlag("MinHeapFreeRatio");
        oldMaxFree = getFlag("MaxHeapFreeRatio");
        setFlag("MinHeapFreeRatio", "1");
        setFlag("MaxHeapFreeRatio", "10");
        setFlag("G1PeriodicGCInterval", String.valueOf(GC_EVERY_MS));
        System.gc();
        info("AFK adjustments on. Memory before: " + before + ", after: " + heapText() + ".");
    }

    @Override
    public void onDeactivate() {
        client.noRender = false;
        if (!saved || client.options == null) return;
        client.options.framerateLimit().set(oldFps);
        client.options.renderDistance().set(oldRender);
        client.options.simulationDistance().set(oldSim);
        client.options.particles().set(oldParticles);
        client.options.getSoundSourceOptionInstance(SoundSource.MASTER).set(oldVolume);
        // the larger value first, so the minimum never goes above the maximum
        if (oldMaxFree != null) setFlag("MaxHeapFreeRatio", oldMaxFree);
        if (oldMinFree != null) setFlag("MinHeapFreeRatio", oldMinFree);
        setFlag("G1PeriodicGCInterval", "0");
        saved = false;
        info("AFK adjustments off: everything restored.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!saved) return;
        apply();   // the game or another module may have changed them

        long now = System.currentTimeMillis();
        long since = now - lastFrame;
        if (since >= frameInterval.get()) {
            lastFrame = now;
            since = 0;
        }
        client.noRender = !(since < WINDOW_MS || client.screen != null);

        if (now - lastGc >= GC_EVERY_MS) {
            lastGc = now;
            System.gc();
        }
    }

    private void apply() {
        if (client.options.framerateLimit().get() != 10) client.options.framerateLimit().set(10);
        if (client.options.renderDistance().get() != 2) client.options.renderDistance().set(2);
        if (client.options.simulationDistance().get() != 5) client.options.simulationDistance().set(5);
        if (client.options.particles().get() != ParticleStatus.MINIMAL) client.options.particles().set(ParticleStatus.MINIMAL);
        if (client.options.getSoundSourceOptionInstance(SoundSource.MASTER).get() != 0.0) client.options.getSoundSourceOptionInstance(SoundSource.MASTER).set(0.0);
    }

    private static String heapText() {
        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) >> 20;
        return used + " MB used of " + (rt.totalMemory() >> 20) + " MB reserved";
    }

    // The JVM settings are reached by reflection: if this phone's Java does not have them, nothing breaks
    // (only the garbage collection every 30 s remains).

    private static Object diagnosticBean(Class<?> beanClass) throws Exception {
        Class<?> factory = Class.forName("java.lang.management.ManagementFactory");
        return factory.getMethod("getPlatformMXBean", Class.class).invoke(null, beanClass);
    }

    private static String getFlag(String name) {
        try {
            Class<?> beanClass = Class.forName("com.sun.management.HotSpotDiagnosticMXBean");
            Object bean = diagnosticBean(beanClass);
            Object opt = beanClass.getMethod("getVMOption", String.class).invoke(bean, name);
            Method getValue = Class.forName("com.sun.management.VMOption").getMethod("getValue");
            return (String) getValue.invoke(opt);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void setFlag(String name, String value) {
        try {
            Class<?> beanClass = Class.forName("com.sun.management.HotSpotDiagnosticMXBean");
            Object bean = diagnosticBean(beanClass);
            beanClass.getMethod("setVMOption", String.class, String.class).invoke(bean, name, value);
        } catch (Throwable t) {
            // not available here
        }
    }
}
