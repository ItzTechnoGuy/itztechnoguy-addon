package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Mining Recorder by ItzTechnoGuy: switch it on, mine by hand, switch it off. It writes a CSV file
 * (a line every few ticks: position, camera angles, keys, held item, the block you look at, ping)
 * plus an event line for every block you break, and a summary at the end. The file is only for
 * looking at how you mine, so the Area Miner can be tuned from it. Nothing is sent anywhere.
 * Folder: <game folder>/itztechnoguy-recordings/
 */
public class MiningRecorder extends Module {
    private final Minecraft client = Minecraft.getInstance();

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> sampleMs = sg.add(new IntSetting.Builder()
        .name("sample-ms")
        .description("How often a line is written, in ms (50 = every tick, the most exact).")
        .defaultValue(50).range(50, 1000).sliderRange(50, 500).build());

    private final Setting<Boolean> chatInfo = sg.add(new BoolSetting.Builder()
        .name("chat-info")
        .description("Say the file path and a short summary in chat when the recording stops.")
        .defaultValue(true).build());

    private BufferedWriter out;
    private Path file;
    private long start, lastSample, lastFlush;

    // target tracking
    private BlockPos preHitPos;
    private String preHitId = "-";
    private BlockPos targetPos;
    private String targetId;
    private long targetSince;

    // statistics
    private int broken;
    private long sumBreakMs, lastBreakAt, sumGapMs, gaps, maxGapMs, attackTicks, ticks;
    private int pauses;          // 2 s or more without breaking a block
    private double walked, sumTurn, maxTurn;
    private double lastX, lastZ;
    private float lastYaw, lastPitch;
    private long lastTurnT;
    private boolean first;

    public MiningRecorder() {
        super(ItzTechnoGuyAddon.CATEGORY, "mining-recorder", "Records how you mine by hand into a file (position, camera, keys, blocks broken) so the Area Miner can be tuned from it. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        try {
            Path dir = client.gameDirectory.toPath().resolve("itztechnoguy-recordings");
            Files.createDirectories(dir);
            file = dir.resolve("mining-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()) + ".csv");
            out = Files.newBufferedWriter(file);
            out.write("# ItzTechnoGuy mining recording. T rows: T,ms,x,y,z,yaw,pitch,keys(WASD J=jump S=sneak R=sprint A=attack),slot,item,target block,target pos,breaking,ping\n");
            out.write("# E rows: E,ms,BROKE,block,pos,ms from first hit to break\n");
        } catch (Throwable t) {
            error("Could not create the recording file: " + t.getMessage());
            out = null;
            toggle();
            return;
        }
        start = System.currentTimeMillis();
        lastSample = 0;
        lastFlush = start;
        targetPos = null;
        targetId = null;
        broken = 0;
        sumBreakMs = 0;
        lastBreakAt = start;
        sumGapMs = 0;
        gaps = 0;
        maxGapMs = 0;
        attackTicks = 0;
        ticks = 0;
        pauses = 0;
        walked = 0;
        sumTurn = 0;
        maxTurn = 0;
        first = true;
        info("Recording started. Mine by hand, then turn the module off.");
    }

    @Override
    public void onDeactivate() {
        if (out == null) return;
        long dur = System.currentTimeMillis() - start;
        String summary = summary(dur);
        try {
            out.write("# SUMMARY " + summary + "\n");
            out.flush();
            out.close();
        } catch (Throwable t) {
            error("Could not finish the file: " + t.getMessage());
        }
        out = null;
        if (chatInfo.get()) {
            info("Recording saved: " + file.toAbsolutePath());
            info(summary);
        }
    }

    /** Before the game handles the click, so the block is still there. */
    @EventHandler
    private void onPre(TickEvent.Pre event) {
        if (out == null || client.player == null || client.level == null) return;
        if (client.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            preHitPos = bhr.getBlockPos();
            preHitId = idOf(client.level.getBlockState(preHitPos));
        } else {
            preHitPos = null;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (out == null || client.player == null || client.level == null) return;
        long now = System.currentTimeMillis();
        long t = now - start;
        ticks++;
        boolean attack = client.options.keyAttack.isDown();
        if (attack) attackTicks++;

        // --- target block and break detection
        BlockPos hit = null;
        String hitId = "-";
        if (client.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            hit = bhr.getBlockPos();
            hitId = idOf(client.level.getBlockState(hit));
        }
        if (targetPos != null && client.level.getBlockState(targetPos).isAir()) {
            long took = now - targetSince;
            event(t, "BROKE," + targetId + "," + targetPos.getX() + " " + targetPos.getY() + " " + targetPos.getZ() + "," + took);
            broken++;
            sumBreakMs += took;
            long gap = now - lastBreakAt;
            if (broken > 1) {
                sumGapMs += gap;
                gaps++;
                maxGapMs = Math.max(maxGapMs, gap);
            }
            if (gap >= 2000) pauses++;
            lastBreakAt = now;
            targetPos = null;
        }
        if (attack && hit != null && !hit.equals(targetPos)) {
            targetPos = hit;
            targetId = hit.equals(preHitPos) ? preHitId : hitId;
            targetSince = now;
        }

        // --- camera speed and walking distance (every tick)
        double x = client.player.getX(), z = client.player.getZ();
        float yaw = client.player.getYRot(), pitch = client.player.getXRot();
        if (!first) {
            walked += Math.hypot(x - lastX, z - lastZ);
            double dt = Math.max(1, now - lastTurnT) / 1000.0;
            double dy = Math.abs(((yaw - lastYaw + 540f) % 360f) - 180f);
            double turn = Math.hypot(dy, Math.abs(pitch - lastPitch)) / dt;
            sumTurn += turn;
            maxTurn = Math.max(maxTurn, turn);
        }
        first = false;
        lastX = x;
        lastZ = z;
        lastYaw = yaw;
        lastPitch = pitch;
        lastTurnT = now;

        // --- the sampled line
        if (t - lastSample >= sampleMs.get()) {
            lastSample = t;
            String keys = (client.options.keyUp.isDown() ? "W" : ".") + (client.options.keyLeft.isDown() ? "A" : ".")
                + (client.options.keyDown.isDown() ? "S" : ".") + (client.options.keyRight.isDown() ? "D" : ".")
                + (client.options.keyJump.isDown() ? "J" : ".") + (client.options.keyShift.isDown() ? "S" : ".")
                + (client.options.keySprint.isDown() ? "R" : ".") + (attack ? "A" : ".");
            String item = idOfItem();
            String tp = hit == null ? "-" : hit.getX() + " " + hit.getY() + " " + hit.getZ();
            boolean breaking = client.gameMode != null && client.gameMode.isDestroying();
            write("T," + t + "," + round(x) + "," + round(client.player.getY()) + "," + round(z) + ","
                + round(yaw) + "," + round(pitch) + "," + keys + "," + client.player.getInventory().getSelectedSlot() + ","
                + item + "," + hitId + "," + tp + "," + breaking + "," + ping());
        }
        if (now - lastFlush > 2000) {
            lastFlush = now;
            try {
                out.flush();
            } catch (Throwable ignored) {
                // keep going
            }
        }
    }

    private String summary(long durMs) {
        double sec = Math.max(1, durMs) / 1000.0;
        return "duration " + Math.round(sec) + " s, blocks broken " + broken
            + (broken > 0 ? " (" + Math.round(broken * 60.0 / sec * 10) / 10.0 + " per minute, first hit to break avg " + (sumBreakMs / broken) + " ms)" : "")
            + ", avg gap between breaks " + (gaps > 0 ? (sumGapMs / gaps) + " ms, longest " + maxGapMs + " ms" : "-")
            + ", pauses of 2 s or more " + pauses
            + ", walked " + Math.round(walked) + " blocks"
            + ", attack held " + (ticks > 0 ? Math.round(attackTicks * 100.0 / ticks) : 0) + "% of the time"
            + ", camera avg " + (ticks > 1 ? Math.round(sumTurn / (ticks - 1)) : 0) + " deg/s, max " + Math.round(maxTurn) + " deg/s";
    }

    private void event(long t, String text) {
        write("E," + t + "," + text);
    }

    private void write(String line) {
        try {
            out.write(line);
            out.write('\n');
        } catch (Throwable t) {
            // disk problem: stop quietly
            out = null;
            toggle();
        }
    }

    private int ping() {
        try {
            var conn = client.getConnection();
            if (conn == null) return -1;
            var info = conn.getPlayerInfo(client.player.getUUID());
            return info == null ? -1 : info.getLatency();
        } catch (Throwable t) {
            return -1;
        }
    }

    private String idOf(BlockState state) {
        return BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
    }

    private String idOfItem() {
        return BuiltInRegistries.ITEM.getKey(client.player.getMainHandItem().getItem()).getPath();
    }

    private static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
