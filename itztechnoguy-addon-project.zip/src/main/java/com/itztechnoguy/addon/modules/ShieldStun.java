package com.itztechnoguy.addon.modules;

import com.itztechnoguy.addon.ItzTechnoGuyAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

/**
 * Shield Stun by ItzTechnoGuy.
 *
 * The moment a player in your crosshair raises a shield against you, the module switches to an axe,
 * hits once (an axe disables the shield for a few seconds) and switches back to the weapon you were
 * holding, all in the same game tick. Each target is only stunned again after "stun-delay".
 */
public class ShieldStun extends Module {
    private final Minecraft client = Minecraft.getInstance();
    private final Map<Integer, Long> lastStun = new HashMap<>();
    private long switchBackAt;
    /** When this module last stunned someone (read by Trigger Bot so the two never hit twice). */
    public long lastStunTime;
    private boolean warnedNoAxe;

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> requireFacing = sg.add(new BoolSetting.Builder()
        .name("only-when-facing-you")
        .description("Only when the shield is turned toward you (a shield only blocks hits from the front).")
        .defaultValue(true).build());

    private final Setting<Integer> stunDelay = sg.add(new IntSetting.Builder()
        .name("stun-delay")
        .description("Do not stun the same player again for this long, in ms (a disabled shield stays disabled for about 5 seconds).")
        .defaultValue(1500).range(0, 10000).sliderRange(0, 6000).build());

    private final Setting<Boolean> switchBack = sg.add(new BoolSetting.Builder()
        .name("switch-back")
        .description("Go back to the item you were holding after the hit.")
        .defaultValue(true).build());

    private final Setting<Integer> switchBackDelay = sg.add(new IntSetting.Builder()
        .name("switch-back-delay")
        .description("Time between the axe hit and switching back, in ms. 0 = in the same tick.")
        .defaultValue(0).range(0, 1000).sliderRange(0, 300)
        .visible(switchBack::get).build());

    private final Setting<Boolean> chatMessage = sg.add(new BoolSetting.Builder()
        .name("chat-message")
        .description("Print a message in the chat for every stun.")
        .defaultValue(false).build());

    public ShieldStun() {
        super(ItzTechnoGuyAddon.CATEGORY, "shield-stun", "Instantly hits a raised shield with an axe and switches back to your weapon. By ItzTechnoGuy.");
    }

    @Override
    public void onActivate() {
        lastStun.clear();
        switchBackAt = 0;
        warnedNoAxe = false;
    }

    @Override
    public void onDeactivate() {
        if (switchBackAt != 0) {
            InvUtils.swapBack();
            switchBackAt = 0;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        long now = System.currentTimeMillis();

        // Delayed switch back.
        if (switchBackAt != 0) {
            if (now >= switchBackAt) {
                InvUtils.swapBack();
                switchBackAt = 0;
            }
            return;
        }
        if (client.screen != null) return;

        Entity looked = client.crosshairPickEntity;
        if (!(looked instanceof Player target) || target == client.player) return;
        if (!target.isBlocking()) return;

        double range = client.player.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE);
        if (client.player.distanceTo(target) > range) return;

        if (requireFacing.get()) {
            Vec3 toMe = client.player.position().subtract(target.position()).normalize();
            if (target.getViewVector(1.0F).dot(toMe) <= 0) return;
        }

        Long last = lastStun.get(target.getId());
        if (last != null && now - last < stunDelay.get()) return;

        int axe = bestAxeSlot();
        if (axe < 0) {
            if (!warnedNoAxe) {
                warning("No axe in the hotbar.");
                warnedNoAxe = true;
            }
            return;
        }

        lastStun.put(target.getId(), now);
        lastStunTime = now;

        // Switch to the axe, hit, switch back: the packets are sent in this order in the same tick.
        InvUtils.swap(axe, switchBack.get());
        client.gameMode.attack(client.player, target);
        client.player.swing(InteractionHand.MAIN_HAND);

        if (switchBack.get()) {
            if (switchBackDelay.get() <= 0) InvUtils.swapBack();
            else switchBackAt = now + switchBackDelay.get();
        }
        if (chatMessage.get()) info("Stunned " + target.getName().getString() + "'s shield.");
    }

    /** True while the delayed switch back to the weapon is still pending. */
    public boolean isBusy() {
        return switchBackAt != 0;
    }

    /** True if this module would stun the given target right now (used by Trigger Bot to leave it the hit). */
    public boolean wouldStun(Entity looked) {
        if (client.player == null) return false;
        if (!(looked instanceof Player target) || target == client.player || !target.isBlocking()) return false;
        if (bestAxeSlot() < 0) return false;
        if (requireFacing.get()) {
            Vec3 toMe = client.player.position().subtract(target.position()).normalize();
            if (target.getViewVector(1.0F).dot(toMe) <= 0) return false;
        }
        Long last = lastStun.get(target.getId());
        return last == null || System.currentTimeMillis() - last >= stunDelay.get();
    }

    /** The best axe in the hotbar (netherite first), or -1. */
    private int bestAxeSlot() {
        int best = -1, bestRank = -1;
        for (int i = 0; i < 9; i++) {
            int rank = axeRank(client.player.getInventory().getItem(i));
            if (rank > bestRank) {
                bestRank = rank;
                best = i;
            }
        }
        return best;
    }

    private int axeRank(ItemStack s) {
        if (s.is(Items.NETHERITE_AXE)) return 5;
        if (s.is(Items.DIAMOND_AXE)) return 4;
        if (s.is(Items.IRON_AXE)) return 3;
        if (s.is(Items.STONE_AXE)) return 2;
        if (s.is(Items.GOLDEN_AXE)) return 1;
        if (s.is(Items.WOODEN_AXE)) return 0;
        return -1;
    }
}
