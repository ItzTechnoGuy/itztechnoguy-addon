package com.itztechnoguy.addon;

import com.itztechnoguy.addon.modules.AfkAdjustments;
import com.itztechnoguy.addon.modules.AreaMiner;
import com.itztechnoguy.addon.modules.BowBoost;
import com.itztechnoguy.addon.modules.MendingScan;
import com.itztechnoguy.addon.modules.MiningRecorder;
import com.itztechnoguy.addon.modules.ShieldStun;
import com.itztechnoguy.addon.modules.SilentTotem;
import com.itztechnoguy.addon.modules.TntRefill;
import com.itztechnoguy.addon.modules.XBowCart;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

import java.lang.invoke.MethodHandles;

/** ItzTechnoGuy's Addon (all modules live in the ItzTechnoGuy tab). */
public class ItzTechnoGuyAddon extends MeteorAddon {
    /** The tab that holds all the modules of this addon. */
    public static final Category CATEGORY = new Category("ItzTechnoGuy");

    @Override
    public void onInitialize() {
        // Lets Meteor's event bus call @EventHandler methods inside this package.
        MeteorClient.EVENT_BUS.registerLambdaFactory("com.itztechnoguy.addon",
            (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

        Modules.get().add(new XBowCart());
        Modules.get().add(new SilentTotem());
        Modules.get().add(new MendingScan());
        Modules.get().add(new AreaMiner());
        Modules.get().add(new TntRefill());
        Modules.get().add(new ShieldStun());
        Modules.get().add(new BowBoost());
        Modules.get().add(new MiningRecorder());
        Modules.get().add(new AfkAdjustments());

        MeteorClient.EVENT_BUS.subscribe(new Overlay());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.itztechnoguy.addon";
    }
}
