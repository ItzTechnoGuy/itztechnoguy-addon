package com.itztechnoguy.addon;

import com.itztechnoguy.addon.modules.AreaMiner;
import com.itztechnoguy.addon.modules.InvSession;
import com.itztechnoguy.addon.modules.SnowTrader;
import com.itztechnoguy.addon.modules.XBowCart;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;

/**
 * Always-on listener (it works even when the X-Bow Cart module is switched off): it draws the
 * placement circle and the block outline, listens for the refill key and runs the manual refill.
 */
public class Overlay {
    @EventHandler
    private void onRender(Render3DEvent event) {
        InvSession.backgroundTick(System.currentTimeMillis());
        AreaMiner miner = Modules.get().get(AreaMiner.class);
        if (miner != null) miner.renderSelection(event);
        XBowCart module = Modules.get().get(XBowCart.class);
        if (module == null) return;
        module.backgroundTick(System.currentTimeMillis());
        module.renderCircle(event);
        module.renderHighlight(event);
    }

    @EventHandler
    private void onKey(KeyEvent event) {
        if (event.action != KeyAction.Press) return;
        AreaMiner miner = Modules.get().get(AreaMiner.class);
        if (miner != null) miner.onGlobalKey(event.key(), event.modifiers());
        SnowTrader trader = Modules.get().get(SnowTrader.class);
        if (trader != null) trader.onGlobalKey(event.key(), event.modifiers());
        XBowCart module = Modules.get().get(XBowCart.class);
        if (module == null) return;
        module.onGlobalKey(event.key(), event.modifiers());
    }
}
